These data sets were preprocessed as explained in the following papers:

MINKU, L. L.; YAO, X. . "Software Effort Estimation as a Multi-objective Learning Problem", ACM Transactions on Software Engineering and Methodology, ACM, v. 22, n. 4, article no. 35, 32p., 2013, doi: 10.1145/2522920.2522928. 

MINKU, L. L.; YAO, X. . "Ensembles and Locality: Insight on Improving Software Effort Estimation.", Information and Software Technology, Special Issue on Best Papers from PROMISE 2011, Elsevier, v. 55, n. 8, p. 1512-1528, 2013, doi: 10.1016/j.infsof.2012.09.012. 

MINKU, L. L.; YAO, X.; "An Analysis of Multi-objective Evolutionary Algorithms for Training Ensemble Models Based on Different Performance Measures in Software Effort Estimation", 9th International Conference on Predictive Models in Software Engineering (PROMISE'13), 10p., October 2013, doi: 10.1145/2499393.2499396.

MINKU, L.; YAO, X. . “A Principled Evaluation of Ensembles of Learning Machines for Software Effort Estimation”, Proceedings of the 7th International Conference on Predictive Models in Software Engineering (PROMISE'2011), 10p., Banff, Canada, September 2011, doi: 10.1145/2020390.2020399.