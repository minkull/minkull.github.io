
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 20/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

% Generate data for the stagger problem
% Return a vector containing
% numc0 - vector of number of examples of class c0 generated for each
% concept
% numc1 - vector of number of examples of class c1 generated for each
% concept
% numnoisyc0 - vector of number of examples that should be of class c0 but are noisy, generated for each
% concept
% numnoisyc1 - vector of number of examples that should be of class c1 but are noisy, generated for each
% concept

function [numc0,numc1,numnoisyc0,numnoisyc1] = generateDriftStagger(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,file)

% This is the time in which each concept (not each drift) starts
% We have number_drifts+1 concepts, but time_start_concept has
% number_drifts+2 positions. The last position of time_start_concept is the
% number of time steps, which is when a new concept would start, if there
% was a new one after the last one.
time_start_concept = [0 time_start_drift num_time_steps];

numc0=[];numc1=[];numnoisyc0=[];numnoisyc1=[];
    
for concept=1:number_drifts+1,
    
    % We don't generate graphics for the stagger problem

    % Number of examples to be generated
    num_examples = time_start_concept(concept+1)-time_start_concept(concept);

    hold on;
    
    if (balanced_classes)
        [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateBalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file);         
    else 
        [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateImbalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file);
    end    
    
    numc0 = [numc0 patc0];
    numc1 = [numc1 patc1];
    numnoisyc0 = [numnoisyc0 patnumnoisyc0];
    numnoisyc1 = [numnoisyc1 patnumnoisyc1];
    
    hold off;
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate balanced examples for the circle problem and print them in the
% file.
% Examples from the old concept can appear if speed > 1.
% Generate alternated examples for class 0 and class 1
% The noisy data are equally distributed over the examples, but for
% balanced classes, 2 noisy data (1 for each class) are always
% consecutivelly generated.
% Return the number of 
% patc0 - examples of class c0 generated
% patc1 - examples of class c1 generated
% patnumnoisyc0 - examples that should be from class c0, but are noisy
% patnumnoisyc1 - examples that should be from class c1, but are noisy

function [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateBalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file)

patc1 = 0; patc0 = 0; patnumnoisyc0 = 0; patnumnoisyc1 = 0;
       
% We will generate floor(num_examples/2) examples inside the circle and 
% ceil(num_examples/2) examples outside the circle.
% So, first we generate floor(num_examples/2) examples inside and outside
% the circle, alternating between inside and outside the circle.
while (patnumnoisyc1+patc1 < floor(num_examples/2))

    concept_to_use = determineConceptToUse(concept,patnumnoisyc1+patc1+patnumnoisyc0+patc0,speed,concept_definition);
    op1     = concept_definition(1,concept_to_use);
    op2     = concept_definition(2,concept_to_use);
    op3     = concept_definition(3,concept_to_use);
    and_or1 = concept_definition(4,concept_to_use);
    and_or2 = concept_definition(5,concept_to_use);
    a       = concept_definition(6,concept_to_use);
    b       = concept_definition(7,concept_to_use);
    c       = concept_definition(8,concept_to_use);
    def     = concept_definition(9,concept_to_use);

    % Generate an example class 0
    % <--- We can improve this later to generate examples of a particular class
    % in a more efficient way, as it is done with the other problems
    generated0 = 0;
    while(generated0 == 0)
        color = randColor();
        shape = randShape();
        size = randSize();
    
        if (belongsToConcept(color,shape,size,op1,op2,op3,and_or1,and_or2,a,b,c) == def)
            generated0 = 1;
            if (shouldBeNoisy(patnumnoisyc0+patc0,noise,ceil(num_examples/2),patnumnoisyc0))
                fprintf(file, ['%c,%c,%c,1.0,\n'], color, shape, size);
                patnumnoisyc0 = patnumnoisyc0 + 1;
            else
                fprintf(file, ['%c,%c,%c,0.0,\n'], color, shape, size);
                patc0 = patc0 + 1;
            end
        end
        
    end


    concept_to_use = determineConceptToUse(concept,patnumnoisyc1+patc1+patnumnoisyc0+patc0,speed,concept_definition);
    op1     = concept_definition(1,concept_to_use);
    op2     = concept_definition(2,concept_to_use);
    op3     = concept_definition(3,concept_to_use);
    and_or1 = concept_definition(4,concept_to_use);
    and_or2 = concept_definition(5,concept_to_use);
    a       = concept_definition(6,concept_to_use);
    b       = concept_definition(7,concept_to_use);
    c       = concept_definition(8,concept_to_use);
    def     = concept_definition(9,concept_to_use);
    
    % Generate an example class 1
    % <--- We can improve this later to generate examples of a particular class
    % in a more efficient way, as it is done with the other problems
    generated1 = 0;
    while(generated1 == 0)
        color = randColor();
        shape = randShape();
        size = randSize();
        
        if (belongsToConcept(color,shape,size,op1,op2,op3,and_or1,and_or2,a,b,c) == ~def)
            generated1 = 1;
            if (shouldBeNoisy(patnumnoisyc1+patc1,noise,floor(num_examples/2),patnumnoisyc1))
                fprintf(file, ['%c,%c,%c,0.0,\n'], color, shape, size);
                patnumnoisyc1 = patnumnoisyc1 + 1;
            else
                fprintf(file, ['%c,%c,%c,1.0,\n'], color, shape, size);
                patc1 = patc1 + 1;
            end
        end
    end


end

% check whether we have to add an extra example outside the circle, to
% complete the ceil(num_examples/2) necessary outside the circle.
% <--- We can improve this later to generate examples of a particular class
% in a more efficient way, as it is done with the other problems
if ( floor(num_examples/2) ~=  ceil(num_examples/2))
    
    concept_to_use = determineConceptToUse(concept,patnumnoisyc1+patc1+patnumnoisyc0+patc0,speed,concept_definition);
    op1     = concept_definition(1,concept_to_use);
    op2     = concept_definition(2,concept_to_use);
    op3     = concept_definition(3,concept_to_use);
    and_or1 = concept_definition(4,concept_to_use);
    and_or2 = concept_definition(5,concept_to_use);
    a       = concept_definition(6,concept_to_use);
    b       = concept_definition(7,concept_to_use);
    c       = concept_definition(8,concept_to_use);
    def     = concept_definition(9,concept_to_use);

    % Generate an example class 0
    generated0 = 0;
    while(generated0 == 0)
        color = randColor();
        shape = randShape();
        size = randSize();

        if (belongsToConcept(color,shape,size,op1,op2,op3,and_or1,and_or2,a,b,c) == def)
            generated0 = 1;
            if (shouldBeNoisy(patnumnoisyc0+patc0,noise,ceil(num_examples/2),patnumnoisyc0))
                fprintf(file, ['%c,%c,%c,1.0,\n'], color, shape, size);
                patnumnoisyc0 = patnumnoisyc0 + 1;
            else
                fprintf(file, ['%c,%c,%c,0.0,\n'], color, shape, size);
                patc0 = patc0 + 1;
            end
        end
    end
end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate imbalanced examples for the stagger problem
% if the classes don't need to be balanced, just generate num_examples,
% whithout worry about equally distributing between class 1 and 0 and
% without worry whether a class has more percentage of noisy examples than
% the other.
% Return the number of 
% patc0 - examples of class c0 generated
% patc1 - examples of class c1 generated
% patnumnoisyc0 - examples that should be from class c0, but are noisy
% patnumnoisyc1 - examples that should be from class c1, but are noisy

function [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateImbalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file)

pat = 0;
patc1 = 0; patc0 = 0; patnumnoisyc0 = 0; patnumnoisyc1 = 0;

while (pat < num_examples)
    color = randColor();
    shape = randShape();
    size = randSize();

    concept_to_use = determineConceptToUse(concept,pat,speed,concept_definition);
    op1     = concept_definition(1,concept_to_use);
    op2     = concept_definition(2,concept_to_use);
    op3     = concept_definition(3,concept_to_use);
    and_or1 = concept_definition(4,concept_to_use);
    and_or2 = concept_definition(5,concept_to_use);
    a       = concept_definition(6,concept_to_use);
    b       = concept_definition(7,concept_to_use);
    c       = concept_definition(8,concept_to_use);
    def     = concept_definition(9,concept_to_use);
    
    
    if (belongsToConcept(color,shape,size,op1,op2,op3,and_or1,and_or2,a,b,c) == ~def)
        if (shouldBeNoisy(pat,noise,num_examples,patnumnoisyc1+patnumnoisyc0))
            fprintf(file, ['%c,%c,%c,0.0,\n'], color, shape, size);
            patnumnoisyc1 = patnumnoisyc1+1;
        else
            fprintf(file, ['%c,%c,%c,1.0,\n'], color, shape, size);
            patc1 = patc1 + 1;
        end
    else

        if (shouldBeNoisy(pat,noise,num_examples,patnumnoisyc0+patnumnoisyc1))
            fprintf(file, ['%c,%c,%c,1.0,\n'], color, shape, size);
            patnumnoisyc0 = patnumnoisyc0+1;
        else
            fprintf(file, ['%c,%c,%c,0.0,\n'], color, shape, size);
            patc0 = patc0 + 1;
        end
    end
    
    pat = pat + 1;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate random color

function color = randColor()

color = 3;
while (color == 3)
    color = 3 * rand();
end

if (color < 1)
    color = 'r';
else if (color < 2)
        color = 'g';
    else if (color < 3)
            color = 'b';
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate random size

function size = randSize()

size = 3;
while (size == 3)
    size = 3 * rand();
end

if (size < 1)
    size = 's';
else if (size < 2)
        size = 'm';
    else if (size < 3)
            size = 'l';
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate random shape

function shape = randShape()

shape = 3;
while (shape == 3)
    shape = 3 * rand();
end

if (shape < 1)
    shape = 'r';
else if (shape < 2)
        shape = 't';
    else if (shape < 3)
            shape = 'c';
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check whether the example described by color,shape and size belongs to
% the concept or not.
% Returns 1 if belongs and 0 otherwise.
function belongs = belongsToConcept(color,shape,sizex,op1,op2,op3,and_or1,and_or2,a,b,c)

if (a == 'a')
    a = 'rgb'
else if (a == 'x')
        a = 'rg';
else if (a == 'o')
        a = 'rb';
else if (a == '@')
            a = 'gb';
    end
    end
    end
end

if (b == 'a')
    b = 'rtc';
else if (b == 'x')
        b = 'rt';
else if (b == 'o')
        b = 'rc';
else if (b == '@')
            b = 'tc';
    end
    end
    end
end

if (c == 'a')
    c = 'sml';
else if (c == 'x')
        c = 'sm';
else if (c == 'o')
        c = 'sl';
else if (c == '@')
            c = 'ml';
    end
    end
    end
end

sizefind = size(strfind(a,color));
if (op1 == '=')
    term1 = (sizefind(1) ~= 0);
else term1 = (sizefind(1) == 0);
end

sizefind = size(strfind(b,shape));
if (op2 == '=')
    term2 = (sizefind(1) ~= 0);
else term2 = (sizefind(1) == 0);
end

sizefind = size(strfind(c,sizex));
if (op3 == '=')
    term3 = (sizefind(1) ~= 0);
else term3 = (sizefind(1) == 0);
end

if (and_or1 == '&')
    term12 = (term1 && term2);
else term12 = (term1 || term2);
end

if (and_or2 == '&')
    term123 = (term12 && term3);
else term123 = (term12 || term3);
end

belongs = term123;