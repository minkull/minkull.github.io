%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 17/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check whether the example should be noisy, according to the example
% number, the percentage of noise and the total number of examples to be
% generated for this concept (num_time_steps) and the number of noisy examples generated so
% far
function [noisy] = shouldBeNoisy(example_number,noise,num_time_steps,noisy_examples_so_far)

% number of noisy examples to be generated in total
number_noisy_examples = floor(num_time_steps * noise/100);

if (noise == 0 || noisy_examples_so_far >= number_noisy_examples)
    noisy = 0;
    return;
end

% Every floor(num_time_steps/number_noisy_examples) example is noisy
if (mod(example_number,floor(num_time_steps/number_noisy_examples)) == 0)
    noisy = 1;
else
    noisy = 0;
end

    