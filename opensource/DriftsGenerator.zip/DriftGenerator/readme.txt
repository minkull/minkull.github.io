Author: L. MINKU
www.cs.bham.ac.uk/~minkull

Drift Data Sets Generator
Copyright (C) 2008  L. Minku

This is a GPL open source code. Please, find the GPL license terms in the file gpl-3.0.txt.
If you find any bugs, please email me at F.L.Minku@cs.bham.ac.uk. 

To run the program, open the graphical interface DataSetsGeneratorGUI in Matlab. The Matlab version used to implement this program is 7.0.0.19920 (R14).

If you use this code to a research work that is published, please, cite the following work:

@inproceedings{MinkuYao2008,
    author 		= {Minku, L. and Yao, X.},
    title 		= {The Impact of Diversity on On-line Ensemble Learning in the Presence of Concept Drift},
    booktitle 	= {2008 {IEEE} International Conference on Data Mining ({ICDM'08}) - submitted},
    year 		= {2008},
    address 	= {Pisa, Italy}
}



This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.
