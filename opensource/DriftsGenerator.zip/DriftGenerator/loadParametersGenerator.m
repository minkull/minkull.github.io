%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 17/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

function loadParametersGenerator(handles)

[filename, pathname, filterindex] = uigetfile('*.dsg', 'Drift Data Sets Generator - Load');

if (filename==0)
    return;
end

file = fopen([pathname filename],'r');

tmp = fgetl(file); set(handles.rbtCircle,'Value',str2num(tmp));
tmp = fgetl(file); set(handles.rbtSine,'Value',str2num(tmp));
tmp = fgetl(file); set(handles.rbtMovingHyperplane,'Value',str2num(tmp));
tmp = fgetl(file); set(handles.rbtStagger,'Value',str2num(tmp));

tmp = fgetl(file); set(handles.edConceptDef,'String',tmp);

tmp = fgetl(file); set(handles.edDriftEqCt1,'String',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt2,'String',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt3,'String',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt4,'String',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt5,'String',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt6,'String',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt7,'String',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt8,'String',tmp);

tmp = fgetl(file); set(handles.edDriftEqCt1,'Visible',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt2,'Visible',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt3,'Visible',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt4,'Visible',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt5,'Visible',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt6,'Visible',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt7,'Visible',tmp);
tmp = fgetl(file); set(handles.edDriftEqCt8,'Visible',tmp);

tmp = fgetl(file); set(handles.txtDriftEqCt1,'Visible',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt2,'Visible',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt3,'Visible',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt4,'Visible',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt5,'Visible',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt6,'Visible',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt7,'Visible',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt8,'Visible',tmp);

tmp = fgetl(file); set(handles.txtDriftEqCt1,'String',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt2,'String',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt3,'String',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt4,'String',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt5,'String',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt6,'String',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt7,'String',tmp);
tmp = fgetl(file); set(handles.txtDriftEqCt8,'String',tmp);

tmp = fgetl(file); set(handles.edNumberDrifts,'String',tmp);
tmp = fgetl(file); set(handles.edSpeed,'String',tmp);

tmp = fgetl(file); set(handles.rbtPeriodic,'Value',str2num(tmp));
tmp = fgetl(file); set(handles.rbtNonPeriodic,'Value',str2num(tmp));

tmp = fgetl(file); set(handles.edPeriod,'String',tmp);
tmp = fgetl(file); set(handles.edDriftTimeSteps,'String',tmp);

tmp = fgetl(file); set(handles.edPeriod,'Enable',tmp);
tmp = fgetl(file); set(handles.edDriftTimeSteps,'Enable',tmp);

tmp = fgetl(file); set(handles.edSeverity,'String',tmp);

tmp = fgetl(file); set(handles.chbPredictable,'Value',str2num(tmp));
tmp = fgetl(file); set(handles.chbRecurrent,'Value',str2num(tmp));

tmp = fgetl(file); set(handles.rbtCyclic,'Value',str2num(tmp));
tmp = fgetl(file); set(handles.rbtUnordered,'Value',str2num(tmp));

tmp = fgetl(file); set(handles.rbtCyclic,'Enable',tmp);
tmp = fgetl(file); set(handles.rbtUnordered,'Enable',tmp);

tmp = fgetl(file); set(handles.edNumTimeSteps,'String',tmp);
tmp = fgetl(file); set(handles.edXRange,'String',tmp);
tmp = fgetl(file); set(handles.edYRange,'String',tmp);
tmp = fgetl(file); set(handles.edXRange,'Enable',tmp);
tmp = fgetl(file); set(handles.edYRange,'Enable',tmp);

tmp = fgetl(file); set(handles.rbtImbalancedClasses,'Value',str2num(tmp));
tmp = fgetl(file); set(handles.rbtBalancedClasses,'Value',str2num(tmp));

tmp = fgetl(file); set(handles.edSeed,'String',tmp);
tmp = fgetl(file); set(handles.edNoise,'String',tmp);


fclose(file);