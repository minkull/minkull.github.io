
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 20/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

% Generate data for the moving hyperplane problem
% Return a vector containing
% numc0 - vector of number of examples of class c0 generated for each
% concept
% numc1 - vector of number of examples of class c1 generated for each
% concept
% numnoisyc0 - vector of number of examples that should be of class c0 but are noisy, generated for each
% concept
% numnoisyc1 - vector of number of examples that should be of class c1 but are noisy, generated for each
% concept

function [numc0,numc1,numnoisyc0,numnoisyc1] = generateDriftMovingHyperplane(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,file)

% This is the time in which each concept (not each drift) starts
% We have number_drifts+1 concepts, but time_start_concept has
% number_drifts+2 positions. The last position of time_start_concept is the
% number of time steps, which is when a new concept would start, if there
% was a new one after the last one.
time_start_concept = [0 time_start_drift num_time_steps];

numc0=[];numc1=[];numnoisyc0=[];numnoisyc1=[];
    
for concept=1:number_drifts+1,
    
    % draw the current concept, if d < 3
    % Notice that, afterwards, when we are printing the examples generated,
    % some examples of the old concept will appear if speed > 1. Examples
    % from old concepts are differenciated from noise because noisy
    % examples are printed in red color.
    d = concept_definition(1,concept);
    
    if (d == 1)
        h_fig=figure; % create a new window
        figure(h_fig);
        set(h_fig,'Name',['Concept ' int2str(concept-1)]);
        
        datax = rangex(1):(rangex(2)-rangex(1))/10:rangex(2);
        hold on

        a0 = concept_definition(2,concept);
        a1 = concept_definition(3,concept);
        plot(datax, a1 * datax - a0);
        
        xlim([rangex(1),rangex(2)]);
        ylim([rangey(1),rangey(2)]);

    else if (d == 2)

            h_fig=figure; % create a new window
            figure(h_fig);
            set(h_fig,'Name',['Concept ' int2str(concept-1)]);
            
            [datax1,datax2] = meshgrid(rangex(1):(rangex(2)-rangex(1))/10:rangex(2), rangex(1):(rangex(2)-rangex(1))/10:rangex(2));  

            a0 = concept_definition(2,concept);
            a1 = concept_definition(3,concept);
            a2 = concept_definition(4,concept);
            surf(datax1, datax2, a1 * datax1 + a2 * datax2 - a0);

            zlim([rangey(1),rangey(2)]);
            colormap(bone);
            colorbar;
            
            hold on;

        end
    end    

    % Number of examples to be generated
    num_examples = time_start_concept(concept+1)-time_start_concept(concept);

    if (balanced_classes)
        [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateBalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file);         
    else 
        [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateImbalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file);
    end    
    
    numc0 = [numc0 patc0];
    numc1 = [numc1 patc1];
    numnoisyc0 = [numnoisyc0 patnumnoisyc0];
    numnoisyc1 = [numnoisyc1 patnumnoisyc1];
    
    hold off;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate balanced examples for the moving hyperplane problem, print them in the file
% and plot id d < 3. Examples under or in the plane are represented by blue
% circles and examples over the plane are represented by yellow dots.
% Noisy examples are red x. Examples from the old concept can appear if
% speed > 1.
% Generate alternated examples for class 0 and class 1
% The noisy data are equally distributed over the examples, but for
% balanced classes, 2 noisy data (1 for each class) are always
% consecutivelly generated.
% Return the number of 
% patc0 - examples of class c0 generated
% patc1 - examples of class c1 generated
% patnumnoisyc0 - examples that should be from class c0, but are noisy
% patnumnoisyc1 - examples that should be from class c1, but are noisy

function [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateBalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file)

patc1 = 0; patc0 = 0; patnumnoisyc0 = 0; patnumnoisyc1 = 0;

% We will generate floor(num_examples/2) examples inside the circle and 
% ceil(num_examples/2) examples outside the circle.
% So, first we generate floor(num_examples/2) examples inside and outside
% the circle, alternating between inside and outside the circle.
while (patnumnoisyc1+patc1 < floor(num_examples/2))

    concept_to_use = determineConceptToUse(concept,patnumnoisyc1+patc1+patnumnoisyc0+patc0,speed,concept_definition);
    d = concept_definition(1,concept_to_use);
    a = concept_definition(2,concept_to_use);
    for it=1:d,
        a = [a concept_definition(it+2,concept_to_use)];
    end
    def = concept_definition(d+3,concept_to_use);

    % Generate an example class 0
    generated0 = 0;
    while(generated0 == 0)
        x=[];
        minx = [];
        maxx = [];
        for it=1:d,
            x = [x rangex(1) + (rangex(2)-rangex(1)) * rand()];
            minx = [minx rangex(1)];
            maxx = [maxx rangex(2)];
        end
        %y = rangey(1) + (rangey(2)-rangey(1)) * rand();
        % y = max(rangey(1),hypminx) + (rangey(2)-max(rangey(1),hypminx)) * rand();
        if (def) % If class 1 is over the hyperplane
            hypmaxx = hyperplane(maxx,d,a);
            y = rangey(1) + (min(rangey(2),hypmaxx)-rangey(1)) * rand();
        else % If class 1 is under the hyperplane
            hypminx = hyperplane(minx,d,a);
            y = max(rangey(1),hypminx) + (rangey(2)-max(rangey(1),hypminx)) * rand();
        end

        if (underAndInHyperplane(x,y,d,a) == def)
            generated0 = 1;
            if (shouldBeNoisy(patnumnoisyc0+patc0,noise,ceil(num_examples/2),patnumnoisyc0))
                if (d==1)
                    plot(x,y,'rx');
                else if (d==2)
                        plot3(x(1),x(2),y,'rx');
                    end
                end
                for it=1:d,
                    fprintf(file, ['%f,'], x(it));
                end
                fprintf(file, ['%f,1.0,\n'], y);
                patnumnoisyc0 = patnumnoisyc0 + 1;
            else
                if (d==1)
                    plot(x,y,'y.');
                else if (d==2)
                        plot3(x(1),x(2),y,'y.');
                    end
                end
                for it=1:d,
                    fprintf(file, ['%f,'], x(it));
                end
                fprintf(file, ['%f,0.0,\n'], y);
                patc0 = patc0 + 1;
            end
        end
    end


    concept_to_use = determineConceptToUse(concept,patnumnoisyc1+patc1+patnumnoisyc0+patc0,speed,concept_definition);
    d = concept_definition(1,concept_to_use);
    a = concept_definition(2,concept_to_use);
    for it=1:d,
        a = [a concept_definition(it+2,concept_to_use)];
    end
    def = concept_definition(d+3,concept_to_use);
    
    % Generate an example class 1
    generated1 = 0;
    while(generated1 == 0)
       
        x=[];
        maxx=[];
        minx = [];
        for it=1:d,
            x = [x rangex(1) + (rangex(2)-rangex(1)) * rand()];
            maxx = [maxx rangex(2)];
            minx = [minx rangex(1)];
        end
        %y = rangey(1) + (rangey(2)-rangey(1)) * rand();
        %y = rangey(1) + (min(rangey(2),hypmaxx)-rangey(1)) * rand();
        if (def) % If class 1 is over the hyperplane
            hypminx = hyperplane(minx,d,a);
            y = max(rangey(1),hypminx) + (rangey(2)-max(rangey(1),hypminx)) * rand();
        else % If class 1 is under the hyperplane
            hypmaxx = hyperplane(maxx,d,a);
            y = rangey(1) + (min(rangey(2),hypmaxx)-rangey(1)) * rand();            
        end
        
        if (underAndInHyperplane(x,y,d,a) == ~def)
            generated1 = 1;
            if (shouldBeNoisy(patnumnoisyc1+patc1,noise,floor(num_examples/2),patnumnoisyc1))
                if (d==1)
                    plot(x,y,'rx');
                else if (d==2)
                        plot3(x(1),x(2),y,'rx');
                    end
                end
                for it=1:d,
                    fprintf(file, ['%f,'], x(it));
                end
                fprintf(file, ['%f,0.0,\n'], y);
                patnumnoisyc1 = patnumnoisyc1 + 1;
            else
                if (d==1)
                    plot(x,y,'bo');
                else if (d==2)
                        plot3(x(1),x(2),y,'bo');
                    end
                end
                for it=1:d,
                    fprintf(file, ['%f,'], x(it));
                end
                fprintf(file, ['%f,1.0,\n'], y);
                patc1 = patc1 + 1;
            end
        end
    end


end


% check whether we have to add an extra example class 0, to
% complete the ceil(num_examples/2) necessary outside the circle.
if ( floor(num_examples/2) ~=  ceil(num_examples/2))
    concept_to_use = determineConceptToUse(concept,patnumnoisyc1+patc1+patnumnoisyc0+patc0,speed,concept_definition);
    d = concept_definition(1,concept_to_use);
    a = concept_definition(2,concept_to_use);
    for it=1:d,
        a = [a concept_definition(it+2,concept_to_use)];
    end
    def = concept_definition(d+3,concept_to_use);

    % Generate an example over the hyperplane
    generated0 = 0;
    while(generated0 == 0)
        x=[];
        minx = [];
        maxx = [];
        for it=1:d,
            x = [x rangex(1) + (rangex(2)-rangex(1)) * rand()];
            minx = [minx rangex(1)];
            maxx = [maxx rangex(2)];
        end
        %y = rangey(1) + (rangey(2)-rangey(1)) * rand();
        %y = max(rangey(1),hypminx) + (rangey(2)-max(rangey(1),hypminx)) * rand();
        if (def) % If class 1 is over the hyperplane
            hypmaxx = hyperplane(maxx,d,a);
            y = rangey(1) + (min(rangey(2),hypmaxx)-rangey(1)) * rand();
        else % If class 1 is under the hyperplane
            hypminx = hyperplane(minx,d,a);
            y = max(rangey(1),hypminx) + (rangey(2)-max(rangey(1),hypminx)) * rand();
        end

        if (underAndInHyperplane(x,y,d,a) == def)
            generated0 = 1;
            if (shouldBeNoisy(patnumnoisyc0+patc0,noise,ceil(num_examples/2),patnumnoisyc0))
                if (d==1)
                    plot(x,y,'rx');
                else if (d==2)
                        plot3(x(1),x(2),y,'rx');
                    end
                end
                for it=1:d,
                    fprintf(file, ['%f,'], x(it));
                end
                fprintf(file, ['%f,1.0,\n'], y);
                patnumnoisyc0 = patnumnoisyc0 + 1;
            else
                if (d==1)
                    plot(x,y,'y.');
                else if (d==2)
                        plot3(x(1),x(2),y,'y.');
                    end
                end
                for it=1:d,
                    fprintf(file, ['%f,'], x(it));
                end
                fprintf(file, ['%f,0.0,\n'], y);
                patc0 = patc0 + 1;
            end
        end
    end
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate imbalanced examples for the moving hyperplane problem
% if the classes don't need to be balanced, just generate num_examples,
% whithout worry about equally distributing between class 1 and 0 and
% without worry whether a class has more percentage of noisy examples than
% the other.
% Return the number of 
% patc0 - examples of class c0 generated
% patc1 - examples of class c1 generated
% patnumnoisyc0 - examples that should be from class c0, but are noisy
% patnumnoisyc1 - examples that should be from class c1, but are noisy

function [patc0,patc1,patnumnoisyc0,patnumnoisyc1] = generateImbalancedExamples(concept,speed,num_examples,rangex,rangey,noise,concept_definition,file)

pat = 0;
patc1 = 0; patc0 = 0; patnumnoisyc0 = 0; patnumnoisyc1 = 0;

while (pat < num_examples)
    
    concept_to_use = determineConceptToUse(concept,pat,speed,concept_definition);

    d = concept_definition(1,concept_to_use);
    a = concept_definition(2,concept_to_use);
    for it=1:d,
        a = [a concept_definition(it+2,concept_to_use)];
    end
    def = concept_definition(d+3,concept_to_use);

    x=[];
    for it=1:d,
        x = [x rangex(1) + (rangex(2)-rangex(1)) * rand()];
    end
    y = rangey(1) + (rangey(2)-rangey(1)) * rand();
    
    if (underAndInHyperplane(x,y,d,a) == ~def)
        if (shouldBeNoisy(pat,noise,num_examples,patnumnoisyc1+patnumnoisyc0))
            if (d==1)
                plot(x,y,'rx');
            else if (d==2)
                    plot3(x(1),x(2),y,'rx');
                end
            end
            for it=1:d,
                fprintf(file, ['%f,'], x(it));
            end
            fprintf(file, ['%f,0.0,\n'], y);
            patnumnoisyc1 = patnumnoisyc1 + 1;
        else
            if (d==1)
                plot(x,y,'bo');
            else if (d==2)
                    plot3(x(1),x(2),y,'bo');
                end
            end
            for it=1:d,
                fprintf(file, ['%f,'], x(it));
            end
            fprintf(file, ['%f,1.0,\n'], y);
            patc1 = patc1 + 1;
        end
        
    else

        if (shouldBeNoisy(pat,noise,num_examples,patnumnoisyc0+patnumnoisyc1))
            if (d==1)
                plot(x,y,'rx');
            else if (d==2)
                    plot3(x(1),x(2),y,'rx');
                end
            end
            for it=1:d,
                fprintf(file, ['%f,'], x(it));
            end
            fprintf(file, ['%f,1.0,\n'], y);
            patnumnoisyc0 = patnumnoisyc0 + 1;
        else
            if (d==1)
                plot(x,y,'y.');
            else if (d==2)
                    plot3(x(1),x(2),y,'y.');
                end
            end
            for it=1:d,
                fprintf(file, ['%f,'], x(it));
            end
            fprintf(file, ['%f,0.0,\n'], y);
            patc0 = patc0 + 1;
        end
    end
    
    pat = pat + 1;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check whether the point x1,x2,y is under or in the hyperplane described
% by d,a.
% Returns 1 if it is and 0 otherwise.
function under = underAndInHyperplane(x,y,d,a)

eq = -a(1);

for ita=1:d,
    eq = eq + a(ita+1) * x(ita);
end

under = (y <= eq);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Return a y value for the x values in the hyperplane eq.

function y = hyperplane(x,d,a)

y = -a(1);

for ita=1:d,
    y = y + a(ita+1) * x(ita);
end
