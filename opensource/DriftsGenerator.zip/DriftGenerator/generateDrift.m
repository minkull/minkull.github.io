%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 16/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

function generateDrift(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,problem_type)

[filename, pathname, filterindex] = uiputfile('*.csv', 'Drift Data Sets Generator - Save data set as');

if (filename==0)
    return;
end

file = fopen([pathname filename],'w');

if (problem_type == 'c')
    [numc0,numc1,numnoisyc0,numnoisyc1] = generateDriftCircle(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,file);
else if (problem_type == 's')
    [numc0,numc1,numnoisyc0,numnoisyc1] = generateDriftSine(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,file);
else if (problem_type == 'm')
    [numc0,numc1,numnoisyc0,numnoisyc1] = generateDriftMovingHyperplane(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,file);
else if (problem_type == 't')
    [numc0,numc1,numnoisyc0,numnoisyc1] = generateDriftStagger(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,file);
    end
    end
    end
end

fclose(file);

msg = sprintf('Drift data set generated.\n\n');
for concept=1:number_drifts+1,
    msg = [msg sprintf('Concept %d:\nNumber of examples of class 0: %d.\nNumber of examples of class 1: %d.\nNumber of noisy examples that should belong to class 0: %d.\nNumber of noisy examples that should belong to class 1: %d.\n\n', concept-1, numc0(concept), numc1(concept), numnoisyc0(concept), numnoisyc1(concept))];
end

file = fopen([pathname filename '.log'],'w');
fprintf(file, msg);
fclose(file);

h = msgbox(msg, 'Drift Data Sets Generator - Summary of data set');
