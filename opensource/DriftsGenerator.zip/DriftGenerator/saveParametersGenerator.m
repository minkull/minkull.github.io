
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 17/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

function saveParametersGenerator(handles)

[filename, pathname, filterindex] = uiputfile('*.dsg', 'Drift Data Sets Generator - Save parameters as');

if (filename==0)
    return;
end

file = fopen([pathname filename],'w');

fprintf(file, ['%.1f\n'], get(handles.rbtCircle,'Value'));
fprintf(file, ['%.1f\n'], get(handles.rbtSine,'Value'));
fprintf(file, ['%.1f\n'], get(handles.rbtMovingHyperplane,'Value'));
fprintf(file, ['%.1f\n'], get(handles.rbtStagger,'Value'));

fprintf(file, [get(handles.edConceptDef,'String') '\n']);

fprintf(file, [get(handles.edDriftEqCt1,'String') '\n']);
fprintf(file, [get(handles.edDriftEqCt2,'String') '\n']);
fprintf(file, [get(handles.edDriftEqCt3,'String') '\n']);
fprintf(file, [get(handles.edDriftEqCt4,'String') '\n']);
fprintf(file, [get(handles.edDriftEqCt5,'String') '\n']);
fprintf(file, [get(handles.edDriftEqCt6,'String') '\n']);
fprintf(file, [get(handles.edDriftEqCt7,'String') '\n']);
fprintf(file, [get(handles.edDriftEqCt8,'String') '\n']);

fprintf(file, [get(handles.edDriftEqCt1,'Visible') '\n']);
fprintf(file, [get(handles.edDriftEqCt2,'Visible') '\n']);
fprintf(file, [get(handles.edDriftEqCt3,'Visible') '\n']);
fprintf(file, [get(handles.edDriftEqCt4,'Visible') '\n']);
fprintf(file, [get(handles.edDriftEqCt5,'Visible') '\n']);
fprintf(file, [get(handles.edDriftEqCt6,'Visible') '\n']);
fprintf(file, [get(handles.edDriftEqCt7,'Visible') '\n']);
fprintf(file, [get(handles.edDriftEqCt8,'Visible') '\n']);

fprintf(file, [get(handles.txtDriftEqCt1,'Visible') '\n']);
fprintf(file, [get(handles.txtDriftEqCt2,'Visible') '\n']);
fprintf(file, [get(handles.txtDriftEqCt3,'Visible') '\n']);
fprintf(file, [get(handles.txtDriftEqCt4,'Visible') '\n']);
fprintf(file, [get(handles.txtDriftEqCt5,'Visible') '\n']);
fprintf(file, [get(handles.txtDriftEqCt6,'Visible') '\n']);
fprintf(file, [get(handles.txtDriftEqCt7,'Visible') '\n']);
fprintf(file, [get(handles.txtDriftEqCt8,'Visible') '\n']);

fprintf(file, [get(handles.txtDriftEqCt1,'String') '\n']);
fprintf(file, [get(handles.txtDriftEqCt2,'String') '\n']);
fprintf(file, [get(handles.txtDriftEqCt3,'String') '\n']);
fprintf(file, [get(handles.txtDriftEqCt4,'String') '\n']);
fprintf(file, [get(handles.txtDriftEqCt5,'String') '\n']);
fprintf(file, [get(handles.txtDriftEqCt6,'String') '\n']);
fprintf(file, [get(handles.txtDriftEqCt7,'String') '\n']);
fprintf(file, [get(handles.txtDriftEqCt8,'String') '\n']);

fprintf(file, [get(handles.edNumberDrifts,'String') '\n']);
fprintf(file, [get(handles.edSpeed,'String') '\n']);

fprintf(file, ['%.1f\n'], get(handles.rbtPeriodic,'Value'));
fprintf(file, ['%.1f\n'], get(handles.rbtNonPeriodic,'Value'));

fprintf(file, [get(handles.edPeriod,'String') '\n']);
fprintf(file, [get(handles.edDriftTimeSteps,'String') '\n']);

fprintf(file, [get(handles.edPeriod,'Enable') '\n']);
fprintf(file, [get(handles.edDriftTimeSteps,'Enable') '\n']);

fprintf(file, [get(handles.edSeverity,'String') '\n']);

fprintf(file, ['%.1f\n'], get(handles.chbPredictable,'Value'));
fprintf(file, ['%.1f\n'], get(handles.chbRecurrent,'Value'));

fprintf(file, ['%.1f\n'], get(handles.rbtCyclic,'Value'));
fprintf(file, ['%.1f\n'], get(handles.rbtUnordered,'Value'));

fprintf(file, [get(handles.rbtCyclic,'Enable') '\n']);
fprintf(file, [get(handles.rbtUnordered,'Enable') '\n']);

fprintf(file, [get(handles.edNumTimeSteps,'String') '\n']);
fprintf(file, [get(handles.edXRange,'String') '\n']);
fprintf(file, [get(handles.edYRange,'String') '\n']);
fprintf(file, [get(handles.edXRange,'Enable') '\n']);
fprintf(file, [get(handles.edYRange,'Enable') '\n']);

fprintf(file, ['%.1f\n'], get(handles.rbtImbalancedClasses,'Value'));
fprintf(file, ['%.1f\n'], get(handles.rbtBalancedClasses,'Value'));

fprintf(file, [get(handles.edSeed,'String') '\n']);
fprintf(file, [get(handles.edNoise,'String') '\n']);


fclose(file);