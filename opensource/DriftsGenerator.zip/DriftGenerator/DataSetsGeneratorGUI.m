%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 17/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

function varargout = DataSetsGeneratorGUI(varargin)
% DATASETSGENERATORGUI M-file for DataSetsGeneratorGUI.fig
%      DATASETSGENERATORGUI, by itself, creates a new DATASETSGENERATORGUI or raises the existing
%      singleton*.
%
%      H = DATASETSGENERATORGUI returns the handle to a new
%      DATASETSGENERATORGUI or the handle to
%      the existing singleton*.
%
%      DATASETSGENERATORGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DATASETSGENERATORGUI.M with the given input arguments.
%
%      DATASETSGENERATORGUI('Property','Value',...) creates a new DATASETSGENERATORGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DataSetsGeneratorGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DataSetsGeneratorGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DataSetsGeneratorGUI

% Last Modified by GUIDE v2.5 08-Jul-2008 12:07:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DataSetsGeneratorGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @DataSetsGeneratorGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DataSetsGeneratorGUI is made txtdrifteqct2.
function DataSetsGeneratorGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DataSetsGeneratorGUI (see VARARGIN)

% Choose default command line output for DataSetsGeneratorGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DataSetsGeneratorGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


set(handles.bgrFrequency,'SelectionChangeFcn',@bgrFrequency_SelectionChangeFcn);
set(handles.bgrProblem,'SelectionChangeFcn',@bgrProblem_SelectionChangeFcn);


%load images
img = importdata('equation_circle.JPG');
%select the axes
axes(handles.figCircle);
%place image onto the axes
image(img);
%remove the axis tick marks
axis off
%load images
img = importdata('equation_sine.JPG');
%select the axes
axes(handles.figSine);
%place image onto the axes
image(img);
%remove the axis tick marks
axis off
%load images
img = importdata('equation_movhyper.JPG');
%select the axes
axes(handles.figMovHyper);
%place image onto the axes
image(img);
%remove the axis tick marks
axis off
%load images
img = importdata('equation_stagger.JPG');
%select the axes
axes(handles.figStagger);
%place image onto the axes
image(img);
%remove the axis tick marks
axis off


% --- Outputs from this function are returned to the command line.
function varargout = DataSetsGeneratorGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edPeriod_Callback(hObject, eventdata, handles)
% hObject    handle to edPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edPeriod as text
%        str2double(get(hObject,'String')) returns contents of edPeriod as a double


% --- Executes during object creation, after setting all properties.
function edPeriod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edDriftTimeSteps_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftTimeSteps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftTimeSteps as text
%        str2double(get(hObject,'String')) returns contents of edDriftTimeSteps as a double


% --- Executes during object creation, after setting all properties.
function edDriftTimeSteps_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftTimeSteps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edNumberDrifts_Callback(hObject, eventdata, handles)
% hObject    handle to edNumberDrifts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edNumberDrifts as text
%        str2double(get(hObject,'String')) returns contents of edNumberDrifts as a double


% --- Executes during object creation, after setting all properties.
function edNumberDrifts_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edNumberDrifts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% Frequency radio button selection change actions
function bgrFrequency_SelectionChangeFcn(hObject, eventdata)
 
%retrieve GUI data, i.e. the handles structure
handles = guidata(hObject); 
 
switch get(eventdata.NewValue,'Tag')   % Get Tag of selected object
    case 'rbtPeriodic'
      %execute this code when rbtPeriodic is selected
      set(handles.edPeriod,'Enable','on');
      set(handles.edDriftTimeSteps,'Enable','off');
 
    case 'rbtNonPeriodic'
      %execute this code when rbtNonPeriodic is selected
      set(handles.edPeriod,'Enable','off');
      set(handles.edDriftTimeSteps,'Enable','on');
       
    otherwise
       % Code for when there is no match.
 
end
%updates the handles structure
guidata(hObject, handles);




% Problem radio button selection change actions
function bgrProblem_SelectionChangeFcn(hObject, eventdata)
 
%retrieve GUI data, i.e. the handles structure
handles = guidata(hObject); 
 
switch get(eventdata.NewValue,'Tag')   % Get Tag of selected object

    case 'rbtCircle'
      
      set(handles.edDriftEqCt1,'Visible','on');
      set(handles.edDriftEqCt2,'Visible','on');
      set(handles.edDriftEqCt3,'Visible','on');
      set(handles.edDriftEqCt4,'Visible','off');
      set(handles.edDriftEqCt5,'Visible','off');
      set(handles.edDriftEqCt6,'Visible','off');
      set(handles.edDriftEqCt7,'Visible','off');
      set(handles.edDriftEqCt8,'Visible','off');
      
      set(handles.txtDriftEqCt1,'Visible','on');
      set(handles.txtDriftEqCt2,'Visible','on');
      set(handles.txtDriftEqCt3,'Visible','on');
      set(handles.txtDriftEqCt4,'Visible','off');
      set(handles.txtDriftEqCt5,'Visible','off');
      set(handles.txtDriftEqCt6,'Visible','off');
      set(handles.txtDriftEqCt7,'Visible','off');
      set(handles.txtDriftEqCt8,'Visible','off');
      
      set(handles.txtDriftEqCt1,'String','a:');
      set(handles.txtDriftEqCt2,'String','b:');
      set(handles.txtDriftEqCt3,'String','r:');
      
      set(handles.edDriftEqCt1,'String','');
      set(handles.edDriftEqCt2,'String','');
      set(handles.edDriftEqCt3,'String','');
      
    case 'rbtSine'
      
      set(handles.edDriftEqCt1,'Visible','on');
      set(handles.edDriftEqCt2,'Visible','on');
      set(handles.edDriftEqCt3,'Visible','on');
      set(handles.edDriftEqCt4,'Visible','off');
      set(handles.edDriftEqCt5,'Visible','off');
      set(handles.edDriftEqCt6,'Visible','off');
      set(handles.edDriftEqCt7,'Visible','off');
      set(handles.edDriftEqCt8,'Visible','off');
      
      set(handles.txtDriftEqCt1,'Visible','on');
      set(handles.txtDriftEqCt2,'Visible','on');
      set(handles.txtDriftEqCt3,'Visible','on');
      set(handles.txtDriftEqCt4,'Visible','off');
      set(handles.txtDriftEqCt5,'Visible','off');
      set(handles.txtDriftEqCt6,'Visible','off');
      set(handles.txtDriftEqCt7,'Visible','off');
      set(handles.txtDriftEqCt8,'Visible','off');
      
      set(handles.txtDriftEqCt1,'String','a:');
      set(handles.txtDriftEqCt2,'String','b:');
      set(handles.txtDriftEqCt3,'String','c:');
      
      set(handles.edDriftEqCt1,'String','');
      set(handles.edDriftEqCt2,'String','');
      set(handles.edDriftEqCt3,'String','');
            
    case 'rbtMovingHyperplane'
      
      set(handles.edDriftEqCt1,'Visible','on');
      set(handles.edDriftEqCt2,'Visible','on');
      set(handles.edDriftEqCt3,'Visible','off');
      set(handles.edDriftEqCt4,'Visible','off');
      set(handles.edDriftEqCt5,'Visible','off');
      set(handles.edDriftEqCt6,'Visible','off');
      set(handles.edDriftEqCt7,'Visible','off');
      set(handles.edDriftEqCt8,'Visible','off');
      
      set(handles.txtDriftEqCt1,'Visible','on');
      set(handles.txtDriftEqCt2,'Visible','on');
      set(handles.txtDriftEqCt3,'Visible','off');
      set(handles.txtDriftEqCt4,'Visible','off');
      set(handles.txtDriftEqCt5,'Visible','off');
      set(handles.txtDriftEqCt6,'Visible','off');
      set(handles.txtDriftEqCt7,'Visible','off');
      set(handles.txtDriftEqCt8,'Visible','off');
      
      set(handles.txtDriftEqCt1,'String','d:');
      set(handles.txtDriftEqCt2,'String','a0:');
      
      set(handles.edDriftEqCt1,'String','');
      set(handles.edDriftEqCt2,'String','');
      set(handles.edDriftEqCt3,'String','');
      set(handles.edDriftEqCt4,'String','');
      set(handles.edDriftEqCt5,'String','');
      set(handles.edDriftEqCt6,'String','');
      set(handles.edDriftEqCt7,'String','');
      set(handles.edDriftEqCt8,'String','');
      
         
      
      case 'rbtStagger'
      
      set(handles.edDriftEqCt1,'Visible','on');
      set(handles.edDriftEqCt2,'Visible','on');
      set(handles.edDriftEqCt3,'Visible','on');
      set(handles.edDriftEqCt4,'Visible','on');
      set(handles.edDriftEqCt5,'Visible','on');
      set(handles.edDriftEqCt6,'Visible','on');
      set(handles.edDriftEqCt7,'Visible','on');
      set(handles.edDriftEqCt8,'Visible','on');
      
      set(handles.txtDriftEqCt1,'Visible','on');
      set(handles.txtDriftEqCt2,'Visible','on');
      set(handles.txtDriftEqCt3,'Visible','on');
      set(handles.txtDriftEqCt4,'Visible','on');
      set(handles.txtDriftEqCt5,'Visible','on');
      set(handles.txtDriftEqCt6,'Visible','on');
      set(handles.txtDriftEqCt7,'Visible','on');
      set(handles.txtDriftEqCt8,'Visible','on');
      
      set(handles.txtDriftEqCt1,'String','op1:');
      set(handles.txtDriftEqCt2,'String','op2:');
      set(handles.txtDriftEqCt3,'String','op3:');
      set(handles.txtDriftEqCt4,'String','and/or1:');
      set(handles.txtDriftEqCt5,'String','and/or2:');
      set(handles.txtDriftEqCt6,'String','a:');
      set(handles.txtDriftEqCt7,'String','b:');
      set(handles.txtDriftEqCt8,'String','c:');
      
      set(handles.edDriftEqCt1,'String','');
      set(handles.edDriftEqCt2,'String','');
      set(handles.edDriftEqCt3,'String','');
      set(handles.edDriftEqCt4,'String','');
      set(handles.edDriftEqCt5,'String','');
      set(handles.edDriftEqCt6,'String','');
      set(handles.edDriftEqCt7,'String','');
      set(handles.edDriftEqCt8,'String','');
      
      set(handles.edXRange,'String','');
      set(handles.edYRange,'String','');
      set(handles.edXRange,'Enable','off');
      set(handles.edYRange,'Enable','off');
      
            
      [msg,ok] = sprintf('The possible values for each constant in the equation are:\n- op1,op2,op3: \''=\'' or \''!\''\n- and_or1,and_or2: \''&\'' or \''|\''\n- a: \''r\'',\''g\'',\''b\''\n- b: \''r\'',\''t\'',\''c\''\n- c: \''s\'',\''m\'',\''l\''\nIt is necessary to enter the symbols \'' \''.\nBesides, a,b,c can be \''a\'', \''x\'', \''o\'',\''@\''. For example, considering size,  \''a\'' = (\''s\'' or \''m\'' or \''l\''), \''x\'' = (\''s\'' or \''m\''), \''o\'' = (\''s\'' or \''l\''), \''@\'' = (\''m\'' or \''l\'').');
      msgbox(msg);
      
      
    otherwise
       % Code for when there is no match.
end
%updates the handles structure
guidata(hObject, handles);
      
      

function edSpeed_Callback(hObject, eventdata, handles)
% hObject    handle to edSpeed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edSpeed as text
%        str2double(get(hObject,'String')) returns contents of edSpeed as a double


% --- Executes during object creation, after setting all properties.
function edSpeed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edSpeed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edNumTimeSteps_Callback(hObject, eventdata, handles)
% hObject    handle to edNumTimeSteps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edNumTimeSteps as text
%        str2double(get(hObject,'String')) returns contents of edNumTimeSteps as a double


% --- Executes during object creation, after setting all properties.
function edNumTimeSteps_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edNumTimeSteps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edSeed_Callback(hObject, eventdata, handles)
% hObject    handle to edSeed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edSeed as text
%        str2double(get(hObject,'String')) returns contents of edSeed as a double


% --- Executes during object creation, after setting all properties.
function edSeed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edSeed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chbNoise.
function chbNoise_Callback(hObject, eventdata, handles)
% hObject    handle to chbNoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chbNoise



function edNoise_Callback(hObject, eventdata, handles)
% hObject    handle to edNoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edNoise as text
%        str2double(get(hObject,'String')) returns contents of edNoise as a double


% --- Executes during object creation, after setting all properties.
function edNoise_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edNoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton8.
function radiobutton8_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton8


% --- Executes on button press in radiobutton9.
function radiobutton9_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton9


% --- Executes on button press in radiobutton10.
function radiobutton10_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton10


% --- Executes on button press in radiobutton11.
function radiobutton11_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton11




% --- Executes on button press in btLoad.
function btLoad_Callback(hObject, eventdata, handles)
% hObject    handle to btLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

loadParametersGenerator(handles);


% --- Executes on button press in btSave.
function btSave_Callback(hObject, eventdata, handles)
% hObject    handle to btSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

saveParametersGenerator(handles);


% --- Executes on button press in btGenerate.
function btGenerate_Callback(hObject, eventdata, handles)
% hObject    handle to btGenerate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[seed,number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,problem_type,ok] = readParameters(handles);
if (ok == 0)
    return;
end

% initialize random generator
rand('seed', seed);

% Call the function to create the data set
generateDrift(number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,problem_type);

% --- Executes on button press in btSuggestDrift.
function btSuggestDrift_Callback(hObject, eventdata, handles)
% hObject    handle to btSuggestDrift (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

h = errordlg('Sorry, function not implemented yet.');

function edSeverity_Callback(hObject, eventdata, handles)
% hObject    handle to edSeverity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edSeverity as text
%        str2double(get(hObject,'String')) returns contents of edSeverity as a double


% --- Executes during object creation, after setting all properties.
function edSeverity_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edSeverity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in btShowDriftGraphic.
function btShowDriftGraphic_Callback(hObject, eventdata, handles)
% hObject    handle to btShowDriftGraphic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[seed,number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,problem_type,ok] = readParameters(handles);
if (ok == 0)
    return;
end

showDriftGraphic(rangex,rangey,problem_type,concept_definition,number_drifts);

% --- Executes on button press in chbPredictable.
function chbPredictable_Callback(hObject, eventdata, handles)
% hObject    handle to chbPredictable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chbPredictable


% --- Executes on button press in chbRecurrent.
function chbRecurrent_Callback(hObject, eventdata, handles)
% hObject    handle to chbRecurrent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chbRecurrent

% Verify if checkbox for recurrence is checked
%checkboxStatus = 0, if the box is unchecked, 
%checkboxStatus = 1, if the box is checked
checkboxStatus = get(hObject,'Value');
  
if (checkboxStatus) 
      set(handles.rbtCyclic,'Enable','on');
      set(handles.rbtUnordered,'Enable','on');
else
      set(handles.rbtCyclic,'Enable','off');
      set(handles.rbtUnordered,'Enable','off');
end
      
      
      



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function edDriftEqCt2_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt2 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt2 as a double


% --- Executes during object creation, after setting all properties.
function edDriftEqCt2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edDriftEqCt4_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt4 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt4 as a double


% --- Executes during object creation, after setting all properties.
function edDriftEqCt4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edDriftEqCt3_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt3 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt3 as a double


% --- Executes during object creation, after setting all properties.
function edDriftEqCt3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edDriftEqCt5_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt5 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt5 as a double


% --- Executes during object creation, after setting all properties.
function edDriftEqCt5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edDriftEqCt6_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt6 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt6 as a double


% --- Executes during object creation, after setting all properties.
function edDriftEqCt6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edDriftEqCt8_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt8 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt8 as a double


% --- Executes during object creation, after setting all properties.
function edDriftEqCt8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edDriftEqCt7_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt7 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt7 as a double


% --- Executes during object creation, after setting all properties.
function edDriftEqCt7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function edDriftEqCt1_Callback(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edDriftEqCt1 as text
%        str2double(get(hObject,'String')) returns contents of edDriftEqCt1 as a double

d = str2num(get(hObject,'String'));
if (get(handles.rbtMovingHyperplane,'Value') == get(handles.rbtMovingHyperplane,'Max'))
    
    if (d>=1)
      set(handles.edDriftEqCt3,'Visible','on');
      set(handles.txtDriftEqCt3,'Visible','on');
      set(handles.txtDriftEqCt3,'String','a1:');
    end
    
    if (d>=2)
      set(handles.edDriftEqCt4,'Visible','on');
      set(handles.txtDriftEqCt4,'Visible','on');
      set(handles.txtDriftEqCt4,'String','a2:');
    end
    
    if (d>=3)
      set(handles.edDriftEqCt5,'Visible','on');
      set(handles.txtDriftEqCt5,'Visible','on');
      set(handles.txtDriftEqCt5,'String','a3:');
    end
    
    if (d>=4)
      set(handles.edDriftEqCt6,'Visible','on');
      set(handles.txtDriftEqCt6,'Visible','on');     
      set(handles.txtDriftEqCt6,'String','a4:');
    end
    
    if (d>=5)
      set(handles.edDriftEqCt7,'Visible','on');
      set(handles.txtDriftEqCt7,'Visible','on');
      set(handles.txtDriftEqCt7,'String','a5:');
    end
    
    if (d>=6)
      set(handles.edDriftEqCt8,'Visible','on');
      set(handles.txtDriftEqCt8,'Visible','on');
      set(handles.txtDriftEqCt8,'String','a6:');
    end

    if (d<=1)
      set(handles.edDriftEqCt4,'Visible','off');
      set(handles.txtDriftEqCt4,'Visible','off');
    end
    
    if (d<=2)
      set(handles.edDriftEqCt5,'Visible','off');
      set(handles.txtDriftEqCt5,'Visible','off');
    end
    
    if (d<=3)
      set(handles.edDriftEqCt6,'Visible','off');
      set(handles.txtDriftEqCt6,'Visible','off');
    end
    
    if (d<=4)
      set(handles.edDriftEqCt7,'Visible','off');
      set(handles.txtDriftEqCt7,'Visible','off');     
    end
    
    if (d<=5)
      set(handles.edDriftEqCt8,'Visible','off');
      set(handles.txtDriftEqCt8,'Visible','off');
    end
    
end

% --- Executes during object creation, after setting all properties.
function edDriftEqCt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edDriftEqCt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function edXRange_Callback(hObject, eventdata, handles)
% hObject    handle to edXRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edXRange as text
%        str2double(get(hObject,'String')) returns contents of edXRange as a double


% --- Executes during object creation, after setting all properties.
function edXRange_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edXRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function edYRange_Callback(hObject, eventdata, handles)
% hObject    handle to edYRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edYRange as text
%        str2double(get(hObject,'String')) returns contents of edYRange as a double


% --- Executes during object creation, after setting all properties.
function edYRange_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edYRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function edConceptDef_Callback(hObject, eventdata, handles)
% hObject    handle to edConceptDef (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edConceptDef as text
%        str2double(get(hObject,'String')) returns contents of edConceptDef as a double


% --- Executes during object creation, after setting all properties.
function edConceptDef_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edConceptDef (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


