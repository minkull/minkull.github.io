
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% Last modification: 20/06/08

function showDriftGraphic(rangex,rangey,problem_type,concept_definition,number_drifts)

if (problem_type == 'c')
    drawCircle(rangex,rangey,concept_definition,number_drifts);
else if (problem_type == 's')
        drawSin(rangex,rangey,concept_definition,number_drifts);
else if (problem_type == 'm')
        drawMovingHyperplane(rangex,rangey,concept_definition,number_drifts);
else if (problem_type == 't')
        drawStagger(rangex,rangey,concept_definition,number_drifts);
    end
    end
    end
end


function drawCircle(rangex,rangey,concept_definition,number_drifts)

h_fig=figure; % create a new window
figure(h_fig);

xlim([rangex(1),rangex(2)]);
ylim([rangey(1),rangey(2)]);
axis image;
hold on;
for concept=1:number_drifts+1,
    a = concept_definition(1,concept);
    b = concept_definition(2,concept);
    r = concept_definition(3,concept);
    rectangle('position', [a-r, b-r, 2*r, 2*r],  'curvature', [1, 1], 'LineWidth', 1.5, 'EdgeColor', 'b'); % , 'FaceColor',[0.7 0.7 0.7]
    text(a + 3*r/4, b + 3*r/4, ['C' int2str(concept-1)]);
end
hold off

%legend(r, 't1','t2');

%data = range(1):(range(2)-range(1))/100:range(2);
%colour = [0.5 0.5 0.5];
%fill([data data],circle(data,0.5,0.5,0.1),green);
%axis equal;
%pdecirc(0.5,0.5,0.1,'CCC1');
%pdecirc(0.6,0.6,0.1,'CCC2');
%axis equal;

function drawSin(rangex,rangey,concept_definition,number_drifts)

h_fig=figure; % create a new window
figure(h_fig);
datax = rangex(1):(rangex(2)-rangex(1))/1000:rangex(2);
hold on
for concept=1:number_drifts+1,
    plot(datax,concept_definition(1,concept) * sin(concept_definition(2,concept) * datax) + concept_definition(3,concept));
    text(0, concept_definition(3,concept), ['C' int2str(concept-1)]);
end
xlim([rangex(1),rangex(2)]);
ylim([rangey(1),rangey(2)]);
hold off

function drawMovingHyperplane(rangex,rangey,concept_definition,number_drifts)

d = concept_definition(1,1);
if (d > 2)
    errordlg('Sorry, no graphical interface for d > 2.');
    return;
end;

if (d == 1)
    h_fig=figure; % create a new window
    figure(h_fig);
    datax = rangex(1):(rangex(2)-rangex(1))/10:rangex(2);
    hold on
    for concept=1:number_drifts+1,
        a0 = concept_definition(2,concept);
        a1 = concept_definition(3,concept);
        plot(datax, a1 * datax - a0);
        text(0, -a0, ['C' int2str(concept-1)]);
    end
    xlim([rangex(1),rangex(2)]);
    ylim([rangey(1),rangey(2)]);
    hold off

else % d == 2

    h_fig=figure; % create a new window
    figure(h_fig);
    [datax1,datax2] = meshgrid(rangex(1):(rangex(2)-rangex(1))/10:rangex(2), rangex(1):(rangex(2)-rangex(1))/10:rangex(2));  
    %hold on
    for concept=1:number_drifts+1,
        a0 = concept_definition(2,concept);
        a1 = concept_definition(3,concept);
        a2 = concept_definition(4,concept);
        surf(datax1, datax2, a1 * datax1 + a2 * datax2 - a0);
        hold on
        text(0, 0, -a0, ['C' int2str(concept-1)]);
    end
    %xlim([rangex(1),rangex(2)]);
    zlim([rangey(1),rangey(2)]);
    colormap(bone);
    colorbar;
    hold off

end

function drawStagger(rangex,rangey,concept_definition,number_drifts)

errordlg('Sorry, no graphical interface for the stagger problem.');


