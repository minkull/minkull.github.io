%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 17/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check whether to use the old or the new concept, according to
% the speed of the drift
% current_concept: number of the current concept, starting from 1
% patterns_already_generated: number of patterns generated so far
% vector of  speeds, containing the speed of each drift
% matrix of drift definitions
function [concept_to_use] = determineConceptToUse(current_concept,patterns_already_generated,speed,concept_definition)

    % the speed of the concept c is related to the speed of the drift c-1. So,
    % we create an aditional position in speed not to need to check if we
    % are accessing a valid position by doing speed(concept-1) when concept
    % is 1.
   speed = [1 speed]; 
   
   if (current_concept > 1 && patterns_already_generated+1 < speed(current_concept) && rand() > (patterns_already_generated+1)/speed(current_concept))
        % use the old concept
        concept_to_use = current_concept-1;
    else
        % use the new concept
        concept_to_use = current_concept;
   end
    