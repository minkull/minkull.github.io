
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: L. MINKU
% www.cs.bham.ac.uk/~minkull

% Last modification: 20/06/08

%    Drift Data Sets Generator
%    Copyright (C) 2008  Leandro Minku
%
%    This program is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    This program is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with this program.  If not, see <http://www.gnu.org/licenses/>.
%

% Read and verify whether % the all the necessary parameters were entered. 
% Return the parameters read:
% seed = number representing the seed used to initialize the random generator
% number_drifts = number of drifts
% speed = vector containing the speed of each drift in time steps
% num_time_steps = total number of time steps to be generated
% time_start_drift = vector containing the number of the time step in which each drift starts happening
% rangex = [a,b] a = minimal value of x and b = maximum value of x, for
% problems different from stagger. For stagger, rangex = [].
% rangey = [a,b] a = minimal value of y and b = maximum value of y, for
% problems different from stagger. For stagger, rangex = [].
% balanced_classes = 1 if the classes are supposed to be balanced
% noise = percentage of class noise to be produced
% concept_definition = depend on the problem: the columns always represent
% the values of the constant corresponding to that row for each concept (number of concepts = number of drifts + 1). So,
% we have always number_drift columns.
%   circle: rows represent a, b and r, def.
%   sine: rows represent a, b and c, def.
%   Moving Hyperplane: rows represent d;a0;...;ad;def. The first row contains
%   number_drifts+1 repetitions of d.
%   Stagger: rows represent op1;op2;op3;and_or1;and_or2;a;b;c;def.
% The last row represents the definition of the concept, ie, if it is
% normal (1 inside the circle and 0 outside, 1 under the sine line and 0
% over) or inverted (0 inside the circle and 1 outside, 0 under the sine
% line and 1 over and so on).
% Problem type: 'c' - circle, 's'- sine, 'm'- moving hyperplane, 't'
% stagger.
% ok = status - 1: success, 0: failed to read parameters

function [seed,number_drifts,speed,num_time_steps,time_start_drift,rangex,rangey,balanced_classes,noise,concept_definition,problem_type,ok] = readParameters(handles)
seed=[];number_drifts=[];speed=[];num_time_steps=[];time_start_drift=[];rangex=[];rangey=[];balanced_classes=[];noise=[];concept_definition=[];problem_type=[];ok=1;


% Set the random seed
[seed,ok] = str2num(get(handles.edSeed,'String'));
if (ok == 0)
    h = errordlg('Invalid seed.');
    ok = 0;
    return;
end  

% Check drift properties parameters
[number_drifts,ok] = str2num(get(handles.edNumberDrifts,'String'));
if (ok == 0)
    h = errordlg('Invalid number of drifts.');
    ok = 0;
    return;
end     

% Check if the speeds are numbers
% As they have to be positive integers, even if we have more than 1 speed,
% we can use str2num to check whether they are valid numbers.
[speed,ok] = str2num(get(handles.edSpeed,'String'));
if (ok == 0)
    h = errordlg('Invalid speed.');
    ok = 0;
    return;
end  

speed = eval(get(handles.edSpeed,'String'));
size_speed = size(speed);
if (size_speed(1) ~= 1 || (size_speed(2) ~= 1 && size_speed(2) ~= number_drifts))
    h = errordlg('Invalid number of speeds.');
    ok = 0;
    return;
end

if (size_speed(2) == 1)
    % Speed contains the speed of EACH drift, even if the speeds are the
    % same
    speed = repmat(speed,1,number_drifts);
end

% Check data set properties - total number of time steps
[num_time_steps ok] = str2num(get(handles.edNumTimeSteps,'String'));
if (ok == 0)
    h = errordlg('Invalid total number of time steps.');
    ok = 0;
    return;
end
    
% Check frequency parameters
% if the drift is periodic
if (get(handles.rbtPeriodic,'Value') == get(handles.rbtPeriodic,'Max'))
    [time_start_drift,ok] = str2num(get(handles.edPeriod,'String'));
    if (ok == 0)
        h = errordlg('Please, enter a valid period.');
        ok = 0;
        return;
    else
        time_start_drift = time_start_drift:time_start_drift:num_time_steps-1;
    end
else % if the drift is not periodic
    % Check if the time steps are numbers. As they have to be positive
    % integers, we can use str2num to check that.
    [time_start_drift,ok] = str2num(get(handles.edDriftTimeSteps,'String'));
    if (ok == 0)
        h = errordlg('Please, enter valid time steps for the start of drifts.');
        ok = 0;
        return;
    end  
    time_start_drift = eval(get(handles.edDriftTimeSteps,'String'));
end

size_time_start_drift = size(time_start_drift);
if (size_time_start_drift(2) ~= number_drifts || time_start_drift(size_time_start_drift(2)) >= num_time_steps)
    h = errordlg('The number of drifts, start time of each drift and/or the given number of starts of drifts are not consistent.');
    ok = 0;
    return;
end


% Check whether the noise is formed by numbers and they are percentages
[noise,ok] = str2num(get(handles.edNoise,'String'));
if (ok == 0 || noise > 100 || noise < 0)
    h = errordlg('Invalid noise percentage.');
    ok = 0;
    return;
end 


% Check whether the correct number of values for the equation of the
% problem to generate data were entered
if (get(handles.rbtCircle,'Value') == get(handles.rbtCircle,'Max'))
 
    lasterr('&','');
    a = eval(get(handles.edDriftEqCt1,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for a.');
        ok = 0;
        return;
    end
 
    
    lasterr('&','');
    b = eval(get(handles.edDriftEqCt2,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for b.');
        ok = 0;
        return;
    end
    
    
    lasterr('&','');
    r = eval(get(handles.edDriftEqCt3,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for r.');
        ok = 0;
        return;
    end
    
    
    
    size_a = size(a);
    size_b = size(b);
    size_r = size(r);
    % Check whether the definition of concept constants is composed by num_drifts+1 values 
    
    if (size_a(2) ~= number_drifts+1 || size_b(2) ~= number_drifts+1 || size_r(2) ~= number_drifts+1)
        h = errordlg('Inconsistent number of values for a, b and r, to define the drifts.');
        ok = 0;
        return;
    end    
     
    concept_definition = [a;b;r];
else if (get(handles.rbtSine,'Value') == get(handles.rbtSine,'Max'))

    lasterr('&','');
    a = eval(get(handles.edDriftEqCt1,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for a.');
        ok = 0;
        return;
    end
    
    lasterr('&','');
    b = eval(get(handles.edDriftEqCt2,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for b.');
        ok = 0;
        return;
    end
    
    lasterr('&','');
    c = eval(get(handles.edDriftEqCt3,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for c.');
        ok = 0;
        return;
    end
    
    
    size_a = size(a);
    size_b = size(b);
    size_c = size(c);
    % Check whether the definition of concept constants is composed by num_drifts+1 values 
    
    if (size_a(2) ~= number_drifts+1 || size_b(2) ~= number_drifts+1 || size_c(2) ~= number_drifts+1)
        h = errordlg('Inconsistent number of values for a, b and c, to define the drifts.');
        ok = 0;
        return;
    end     
    
    concept_definition = [a;b;c];
 
else if (get(handles.rbtMovingHyperplane,'Value') == get(handles.rbtMovingHyperplane,'Max'))
    [d,ok] = str2num(get(handles.edDriftEqCt1,'String'));
    if (ok == 0)
        h = errordlg('Invalid value for d.');
        return;
    end
    if (d < 1 || d > 6)
        h = errordlg('The constant d has to be in [1,6]');
        ok = 0;
        return;
    end
    d = repmat(d,1,number_drifts+1);
    
    a = [];
    size_a = [];
    eds = [handles.edDriftEqCt1 handles.edDriftEqCt2 handles.edDriftEqCt3 handles.edDriftEqCt4 handles.edDriftEqCt5 handles.edDriftEqCt6 handles.edDriftEqCt7 handles.edDriftEqCt8];
    for it=0:d,
        
        lasterr('&','');
        tmp = eval(get(eds(it+2),'String'),'[0]');
        [lastmsg, lastid] = lasterr;
        if (lastmsg(1) ~= '&')
            errordlg(['Invalid value for a' num2str(it) '.']);
            ok = 0;
            return;
        end
    
        size_a = size(tmp);
        if (size_a(2) ~= number_drifts+1)
            h = errordlg(['Please, enter a consistent number of values for a' num2str(it) '.']);
            ok = 0;
            return;
        end  
        
        if (it == 0)
            a = tmp;
        else a = [a;tmp];
        end
        
    end
    
    % The first row contains number_drifts+1 repetitions of d. The other rows contain the
    % definitions of ai, from 0 to d.
    concept_definition = [d;a];
    
else if (get(handles.rbtStagger,'Value') == get(handles.rbtStagger,'Max'))
    % check if values are num_drift, and if they're allowed values
    op1 = eval(get(handles.edDriftEqCt1,'String'),'[0]');
    op2 = eval(get(handles.edDriftEqCt2,'String'),'[0]');
    op3 = eval(get(handles.edDriftEqCt3,'String'),'[0]');
    if (op1(1) == 0 || op2(1) == 0 || op3(1) == 0)
        [msg,ok] = sprintf('Op can be either \''=\'' or \''!\''.\nThe symbols \''  \'' are necessary.');
        h = errordlg(msg);
        ok = 0;
        return;
    end
    size_op1 = size(op1);
    size_op2 = size(op2);
    size_op3 = size(op3);
    
    if (size_op1(2) ~= number_drifts+1 || size_op2(2) ~= number_drifts+1 || size_op3(2) ~= number_drifts+1)
        h = errordlg('Inconsistent number of values for op.');
        ok = 0;
        return;
    end 
    
    for i=1:number_drifts+1,
        if ( (op1(i) ~= '=' && op1(i) ~= '!') || (op2(i) ~= '=' && op2(i) ~= '!') || (op3(i) ~= '=' && op3(i) ~= '!') )
            [msg, ok] = sprintf('Op can be either \''=\'' or \''!\''.\nThe symbols \''  \'' are necessary.');
            h = errordlg(msg);
            ok = 0;
            return;
        end  
    end
    
    and_or1 = eval(get(handles.edDriftEqCt4,'String'),'[0]');
    and_or2 = eval(get(handles.edDriftEqCt5,'String'),'[0]');
    if (and_or1(1) == 0 || and_or2(1) == 0)
        [msg,ok] = sprintf('And_or can be either \''&'' or \''|\''. The symbols \''  \'' are necessary.');
        h = errordlg(msg);
        ok = 0;
        return;
    end
    size_and_or1 = size(and_or1);
    size_and_or2 = size(and_or2);
    if (size_and_or1(2) ~= number_drifts+1 || size_and_or2(2) ~= number_drifts+1)
        h = errordlg('Inconsistent number of values and_or.');
        ok = 0;
        return;
    end 
    
    for i=1:number_drifts+1,
        if ( (and_or1(i) ~= '&' && and_or1(i) ~= '|') || (and_or2(i) ~= '&' && and_or2(i) ~= '|') )
            [msg, ok] = sprintf('And_or can be either \''&'' or \''|\''. The symbols \'' \'' are necessary.');
            h = errordlg(msg);
            ok = 0;
            return;
        end 
    end
    
    a = eval(get(handles.edDriftEqCt6,'String'),'[0]');
    b = eval(get(handles.edDriftEqCt7,'String'),'[0]');
    c = eval(get(handles.edDriftEqCt8,'String'),'[0]');
    if (a(1) == 0 || b(1) == 0 || c(1) == 0)
        [msg,ok] = sprintf('Possible values:\n- a: \''r\'',\''g\'',\''b\''\n- b: \''r\'',\''t\'',\''c\''\n- c: \''s\'',\''m\'',\''l\''\nThe symbols \'' \'' are necessary.\nBesides, a,b,c can be \''a\'', \''x\'', \''o\'',\''@\''. For example, considering size, \''a\'' = (\''s\'' or \''m\'' or \''l\''), \''x\'' = (\''s\'' or \''m\''), \''o\'' = (\''s\'' or \''l\''), \''@\'' = (\''m\'' or \''l\'').');
        h = errordlg(msg);
        ok = 0;
        return;
    end
    size_a = size(a);
    size_b = size(b);
    size_c = size(c);
    if (size_a(2) ~= number_drifts+1 || size_b(2) ~= number_drifts+1 || size_c(2) ~= number_drifts+1)
        h = errordlg('Inconsistent number of values a, b or c.');
        ok = 0;
        return;
    end 
    
    for i=1:number_drifts+1,
        if ( (a(i) ~= 'r' && a(i) ~= 'g' && a(i) ~= 'b' && a(i) ~= 'a' && a(i) ~= 'x' && a(i) ~= 'o' && a(i) ~= '@') || (b(i) ~= 'r' && b(i) ~= 't' && b(i) ~= 'c' && b(i) ~= 'a' && b(i) ~= 'x' && b(i) ~= 'o' && b(i) ~= '@') || (c(i) ~= 's' && c(i) ~= 'm' && c(i) ~= 'l' && c(i) ~= 'a' && c(i) ~= 'x' && c(i) ~= 'o' && c(i) ~= '@') )
            [msg,ok] = sprintf('Possible values:\n- a: \''r\'',\''g\'',\''b\''\n- b: \''r\'',\''t\'',\''c\''\n- c: \''s\'',\''m\'',\''l\''\nThe symbols \'' \'' are necessary.\nBesides, a,b,c can be \''a\'',\''x\'', \''o\'',\''@\''. For example, considering size, \''a\'' = (\''s\'' or \''m\'' or \''l\''), \''x\'' = (\''s\'' or \''m\''), \''o\'' = (\''s\'' or \''l\''), \''@\'' = (\''m\'' or \''l\'').');
            h = errordlg(msg);
            ok = 0;
            return;
        end  
    end
    
    concept_definition = [op1;op2;op3;and_or1;and_or2;a;b;c];
    
    end
    end
    end
    
end

% Read the definition of the concept, which is where the class 0 and 1
% should be, e.g., inside or outside the circle.
lasterr('&','');
def = eval(get(handles.edConceptDef,'String'),'[0]');
[lastmsg, lastid] = lasterr;
if (lastmsg(1) ~= '&')
    errordlg('Invalid value for concept definition. Possible values: 0 and 1.');
    ok = 0;
    return;
end

size_def = size(def);
% Check whether the definition of concept is composed by num_drifts+1 values 
if (size_def(2) ~= number_drifts+1)
    h = errordlg('Inconsistent number of values for the concept definition.');
    ok = 0;
    return;
end   

for itdef=1:number_drifts+1,
    if (def(itdef) ~= 0 && def(itdef) ~= 1)
        h = errordlg('Invalid value for concept definition. Possible values: 0 and 1.');
        ok=0;
        return;
    end
end

concept_definition = [concept_definition;def];


    
if (get(handles.rbtCircle,'Value') == get(handles.rbtCircle,'Max'))
    problem_type = 'c';
else if (get(handles.rbtSine,'Value') == get(handles.rbtSine,'Max'))
        problem_type = 's';
    else if (get(handles.rbtMovingHyperplane,'Value') == get(handles.rbtMovingHyperplane,'Max'))
            problem_type = 'm';
        else if (get(handles.rbtStagger,'Value') == get(handles.rbtStagger,'Max'))
                problem_type = 't';
            end
        end
    end
end


% If the problem is not stagger, check the range of values
if (problem_type ~= 't')
    lasterr('&','');
    rangex = eval(get(handles.edXRange,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for x range.');
        ok = 0;
        return;
    end

    lasterr('&','');
    rangey = eval(get(handles.edYRange,'String'),'[0]');
    [lastmsg, lastid] = lasterr;
    if (lastmsg(1) ~= '&')
        errordlg('Invalid value for y range.');
        ok = 0;
        return;
    end


    % Check whether the range is composed by 2 values and min < max
    size_rangex = size(rangex);
    if (size_rangex(2) ~= 2 || rangex(1) >= rangex(2)) 
        h = errordlg('Please, enter a valid range of x values.');
        ok = 0;
        return;
    end

    % Check whether the range is composed by 2 values and min < max
    size_rangey = size(rangey);
    if (size_rangey(2) ~= 2 || rangey(1) >= rangey(2)) 
        h = errordlg('Please, enter a valid range of y values.');
        ok = 0;
        return;
    end
end


if (get(handles.rbtBalancedClasses,'Value') == get(handles.rbtBalancedClasses,'Max'))
    balanced_classes = 1;
else
    balanced_classes = 0;
end

ok = 1;
    
    
    
    
    
    
    