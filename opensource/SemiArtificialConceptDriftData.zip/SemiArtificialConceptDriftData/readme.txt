
This are the semi artificial data sets used in:

MINKU, L. L.; WHITE, A. P.; YAO, X. . "The Impact of Diversity on On-line Ensemble Learning in the Presence of Concept Drift.", IEEE Transactions on Knowledge and Data Engineering, IEEE, v. 22, n. 5, p. 730-742, 2010, doi: 10.1109/TKDE.2009.156. 

Please, find their description in the paper above and find additional detailed explanation of how they were created, taking as example the contraceptive data set, below:

For the semi-artificial data sets, the N examples of each partition are first separated into 75% for composing the training set and 25% for composing the test set. So, taking the example of contraceptive training set, N = 1,473 examples. That means that each section of the testing data set is composed of (int) 0.25N = 368 and each section of the training data set is composed of N - (int) 0.25N = 1105. So, the total size of the contraceptive training set is 3 * 1105 = 3315 and the total size of the contraceptive testing set is 3 * 368 = 1104.

Then, the first 1105 examples of the contraceptive training set are of the first concept. As the drifting time for the first drift is 0.25N, the first drift takes 0.25 * 1,473 time steps to complete. So, the next 0.25 * 1,473 examples of the training set are picked randomly from either the first or second concepts, with probabilities based on a linear degree of dominance function. The remaining 1105 - 0.25 * 1,473 examples of the second section belong completely to the second concept.

The contraceptive test set is composed of three sections which belong purely to the first, second and third concepts.

Each line of the training and testing files contain one example. Each line contains first the input attributes and then output attribute. 

The attributes are described in the corresponding names files, where the first line represents the output attribute and the remaining lines represent the input attributes. Continuous input attributes are followed by the word "continuous", whereas categorical attributes are followed by their possible values.

