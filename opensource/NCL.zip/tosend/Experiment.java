
/****************************************************************************
 Author: LEANDRO LEI MINKU
 L.L.Minku@cs.bham.ac.uk
 www.cs.bham.ac.uk/~minkull

    Incremental NCL
    Copyright (C) 2007 The University of Birmingham

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, check <http://www.gnu.org/licenses/>.
*****************************************************************************/
 
import components.*;

import java.util.*;

public class Experiment {

	/**
	 * A pretty basic single run throug of one ensemble that learns a training set and 
	 * then tests on seperate set. Should be fairly easy to put it in a loop to do a 
	 * number of runs on different training sets
	 */

	
	public static void main(String[] args) throws UnknownNodeTypeException{
		
		if (args.length < 2)
		{
			System.err.println( "Incorrect number of parameters." );
			System.err.println( "Use: java Experiment <type of model> <type of incremental> <parameters_file>" );
			System.exit(1);
		}
		
		//set to false to stop printing progress updates
		boolean verbose = true;

		// This is inside RunModels now
		// Set up a Random number generator
		/*Date dt = new Date();
		long time_seed = dt.getTime();
		//time_seed = 1169811971095L; //1169814536017L; //1169820601214L; //1169811971095L; //1169813742666L; //1169906455778L; //1169902692744L; 
		System.out.println("Seed: "+time_seed);
		Globals.generalRand = new Random(time_seed);*/
		
		RunModels run = new RunModels();
		
		// single normal MLP
		if (args.length == 2 && args[0].compareToIgnoreCase(new String("mlp")) == 0)
		{
			System.out.println("Running simple MLP");
			run.rMLP(verbose,args[1]);
		}
		// normal NCL ensemble
		else if (args.length == 3 && args[0].compareToIgnoreCase(new String("ensncl")) == 0 && args[1].compareToIgnoreCase(new String("noinc")) == 0)
		{
			System.out.println("Running ncl ensemble");
			run.rEnsemble(verbose, LearningParameters.NCL, args[2]);
		}
		// normal Backprop ensemble
		else if (args.length == 3 && args[0].compareToIgnoreCase(new String("ensback")) == 0 && args[1].compareToIgnoreCase(new String("noinc")) == 0)
		{
			System.out.println("Running backpropagation ensemble");
			run.rEnsemble(verbose, LearningParameters.STANDARD_BACKPROP, args[2]);
		}
		// fixed incremental NCL ensemble
		else if (args.length == 3 && args[0].compareToIgnoreCase(new String("ensncl")) == 0  && args[1].compareToIgnoreCase(new String("fixedinc")) == 0)
		{
			System.out.println("Running fixed incremental ncl ensemble");
			run.rIncEnsemble(verbose, LearningParameters.NCL, LearningParameters.FIXED_INCREMETNAL, args[2]);
		}
		// fixed incremental Backprop ensemble
		else if (args.length == 3 && args[0].compareToIgnoreCase(new String("ensback")) == 0  && args[1].compareToIgnoreCase(new String("fixedinc")) == 0)
		{
			System.out.println("Running fixed incremental backpropagation ensemble");
			run.rIncEnsemble(verbose, LearningParameters.STANDARD_BACKPROP, LearningParameters.FIXED_INCREMETNAL, args[2]);
		}
		// growing incremental NCL ensemble
		else if (args.length == 3 && args[0].compareToIgnoreCase(new String("ensncl")) == 0  && args[1].compareToIgnoreCase(new String("growinc")) == 0)
		{
			System.out.println("Running growing incremental ncl ensemble");
			run.rIncEnsemble(verbose, LearningParameters.NCL, LearningParameters.GROWING_INCREMENTAL, args[2]);
		}
		// growing incremental Backprop ensemble
		else if (args.length == 3 && args[0].compareToIgnoreCase(new String("ensback")) == 0  && args[1].compareToIgnoreCase(new String("growinc")) == 0)
		{
			System.out.println("Running growing incremental backpropagation ensemble");
			run.rIncEnsemble(verbose, LearningParameters.STANDARD_BACKPROP, LearningParameters.GROWING_INCREMENTAL, args[2]);
		}
		else
		{
			System.err.println( "Incorrect number of parameters or combination of parameters." );
			System.err.println( "Use: java Experiment <type of model> <type of incremental> <parameters file>" );
			System.exit(1);
		}
			
		Date dt2 = new Date();
		System.out.println("Time2: "+dt2.getTime());
		long time = dt2.getTime() - run.timeSeed;
		System.out.println( "Total execution time: " + time + "ms");
		

		
		//can also use the following commented code to set a different combination scheme and 
		//then simply repeat tests.
		//ens.setCombinationScheme(new MAJ());
		
	}
	

}
