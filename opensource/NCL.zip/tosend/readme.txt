

    Please, we ask that any work produced using this program acknowledge its source. Part of the code was written by Peter Duell and part by Leandro Minku.

    We also ask the following paper to be cited:

    MINKU, F. L.; INOUE, H.; YAO, X. . �Negative Correlation in Incremental Learning�, Natural Computing Journal - Special Issue on Nature-inspired Learning and Adaptive Systems, v. 8, n. 2, p. 289-320, Springer, 2009, doi: 10.1007/s11047-007-9063-7.

    Should you wish to redistribute it, we ask you to let us know by emailing 
    Leandro Lei Minku - L.L.Minku@cs.bham.ac.uk

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, check <http://www.gnu.org/licenses/>.