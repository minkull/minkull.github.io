package components;
import java.util.*;

public abstract class ArrayHandler {
	
	
	public static float[] normalise(float[] array){
		float max = maxCellValue(array);
		float min = minCellValue(array);
		for(int i = 0; i < array.length; i++){
			array[i] = (array[i] - min )/(max - min);
		}
		return array;
	}
	
	
	
	public static int maxCellLocation(double[] array){
		int loc = -1;
		double maxSoFar = 0;
		for(int i = 0; i < array.length; i++){
			if(i == 0){
				maxSoFar = array[i];
				loc = i;
			}
			else{
				if(maxSoFar<array[i]){
					maxSoFar = array[i];
					loc = i;
				}
			}
		}
		
		return loc;
	}
	
	public static int maxCellLocation(float[] array){
		int loc = -1;
		double maxSoFar = 0;
		for(int i = 0; i < array.length; i++){
			if(i == 0){
				maxSoFar = array[i];
				loc = i;
			}
			else{
				if(maxSoFar<array[i]){
					maxSoFar = array[i];
					loc = i;
				}
			}
		}
		
		return loc;
	}
	
	public static int minCellLocation(double[] array){
		int loc = -1;
		double minSoFar = 0;
		for(int i = 0; i < array.length; i++){
			if(i == 0){
				minSoFar = array[i];
				loc = i;
			}
			else{
				if(minSoFar>array[i]){
					minSoFar = array[i];
					loc = i;
				}
			}
		}
		
		return loc;
	}
	
	public static int minCellLocation(float[] array){
		int loc = -1;
		double minSoFar = 0;
		for(int i = 0; i < array.length; i++){
			if(i == 0){
				minSoFar = array[i];
				loc = i;
			}
			else{
				if(minSoFar>array[i]){
					minSoFar = array[i];
					loc = i;
				}
			}
		}
		
		return loc;
	}
	
	//returns multiple minimums if >1 with same min value
	public static Vector multiMinCellLocation(float[] array){
		float minValue = minCellValue(array);
		Vector list = new Vector(1);
		for(int i = 0; i < array.length; i++){
			if(array[i] == minValue){
				list.add(new Integer(i));
			}
		}
		return list;
	}
	
	public static int differencesBetweenArrays(float[][] arr1, float[][] arr2){
		int diff = 0;
		for(int i = 0; i < arr1.length; i++){
			for(int j = 0; j < arr1[i].length; j++){
				if(arr1[i][j] != arr2[i][j]){
					diff++;
				}
			}
			
		}
		return diff;
	}
	
	public static float[] removeElement(float[] array, int element){
		float[] array2 = new float[array.length - 1];
		int count = 0;
		for(int i = 0; i < array.length; i++){
			if(i != element){
				array2[count] = array[i];
				count++;
			}
			
		}
		return array2;
		
	}
	
	public static int[] maxCellLocation(double[][] matrix){
		int[] loc = new int[2];
		loc[0] = -1;
		loc[1] = -1;
		double maxSoFar = 0;
		for(int i = 0; i < matrix.length; i++){
			for(int j = 0; j < matrix[i].length; j++){
				if(i == 0 && j == 0){
					maxSoFar = matrix[i][j];
					loc[0] = i;
					loc[1] = j;
				}
				else{
					if(maxSoFar<matrix[i][j]){
						maxSoFar = matrix[i][j];
						loc[0] = i;
						loc[1] = j;
					}
				}
			}
			
		}
		
		return loc;
		
	}
	
	public static int[] maxCellLocation(float[][] matrix){
		int[] loc = new int[2];
		loc[0] = -1;
		loc[1] = -1;
		double maxSoFar = 0;
		for(int i = 0; i < matrix.length; i++){
			for(int j = 0; j < matrix[i].length; j++){
				if(i == 0 && j == 0){
					maxSoFar = matrix[i][j];
					loc[0] = i;
					loc[1] = j;
				}
				else{
					if(maxSoFar<matrix[i][j]){
						maxSoFar = matrix[i][j];
						loc[0] = i;
						loc[1] = j;
					}
				}
			}
			
		}
		
		return loc;
		
	}
	
	public static double maxCellValue(double[] array){
		return array[ArrayHandler.maxCellLocation(array)];
	}
	public static float maxCellValue(float[] array){
		return array[ArrayHandler.maxCellLocation(array)];
	}
	
	public static double minCellValue(double[] array){
		return array[ArrayHandler.minCellLocation(array)];
	}
	public static float minCellValue(float[] array){
		return array[ArrayHandler.minCellLocation(array)];
	}
	
	public static int maxCellLocation(int[] array){
		int loc = -1;
		int maxSoFar = 0;
		for(int i = 0; i < array.length; i++){
			if(i == 0){
				maxSoFar = array[i];
				loc = i;
			}
			else{
				if(maxSoFar<array[i]){
					maxSoFar = array[i];
					loc = i;
				}
			}
		}
		
		return loc;
	}
	
	public static double getAverage(double[] a){
		double total = 0;
		for(int i = 0; i < a.length; i++){
			total += a[i];
		}
		return total / (a.length*1d);
	}
	
	public static float getAverage(float[] a){
		double total = 0;
		for(int i = 0; i < a.length; i++){
			total += a[i];
		}
		return (float)total / (a.length*1f);
	}
	
	public static int[] countTruesPerSecondArray(boolean[][] m){
		int[] count = new int[m[0].length];
		for(int i = 0; i < m.length; i++){
			for(int j = 0; j < m[i].length; j++){
				if(m[i][j])
					count[j] ++;
			}
		}
		return count;
	}
	
	//first array considered to be rows, second considered to be columns
	public static int countNumberOfRowsWhereAllTrue(boolean[][] m){
		int count = 0;
		for(int i = 0; i < m.length; i++){
			boolean correctSoFar = true;
			for(int j = 0; j < m[i].length; j++){
				if(!m[i][j])
					correctSoFar = false;
			}
			if(correctSoFar)
				count ++;
		}
		return count;
		
	}
	
	public static String arrayToString(double[] array){
		String s = "";
		for(int i = 0; i<array.length; i++){
			s = s+array[i] + " ";
		}
		return s;
	}
	
	public static String arrayToString(float[] array){
		String s = "";
		for(int i = 0; i<array.length; i++){
			s = s+array[i] + " ";
		}
		return s;
	}
	
	public static String arrayToString(int[] array){
		String s = "";
		for(int i = 0; i<array.length; i++){
			s = s+array[i] + " ";
		}
		return s;
	}
	
	public static String arrayToCommaDelimitString(double[] array){
		String s = "";
		for(int i = 0; i<array.length; i++){
			s = s+array[i] + ",";
		}
		return s;
	}
	
	public static String arrayToCommaDelimitString(float[] array){
		String s = "";
		for(int i = 0; i<array.length; i++){
			s = s+array[i] + ",";
		}
		return s;
	}
	
	public static String arrayToCommaDelimitString(int[] array){
		String s = "";
		for(int i = 0; i<array.length; i++){
			s = s+array[i] + ",";
		}
		return s;
	}
	
	public static String arrayToMultiLineString(double[] array){
		String s = "";
		for(int i = 0; i<array.length; i++){
			s = s+ array[i] + "\n";
		}
		return s;
	}
}
