/*
 * Created on 07-Jun-2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package components;

/**
 * @author pmd
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MeanSquareErrorFunction extends ErrorFunction {

	
	public MeanSquareErrorFunction(){
		type = "MSE";
	}
	
	/* (non-Javadoc)
	 * @see eencl_project.components.error_functions.error_function#getError(float, float)
	 */
	public float getError(ErrorParameters param) {
		return (float)(0.5 * (Math.pow((param.estimate - param.target),2.0)));
	}
	
	public float getError(float est, float tar) {
		return (float)(0.5 * (Math.pow((est -tar),2.0)));
	}
	
	public float getDf_by_Da(ErrorParameters param){
		return param.estimate - param.target;
	}
	
	

}
