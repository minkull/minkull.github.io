
/****************************************************************************
 Author: LEANDRO LEI MINKU
 L.L.Minku@cs.bham.ac.uk
 www.cs.bham.ac.uk/~minkull
 
 Incremental NCL
 Copyright (C) 2007 The University of Birmingham
 
 Class: IncNegativeCorrelationLearning
 Description: Implements the Incremental Negative Correlation Learning,
              in which each NN is trained for a different dataset, in a 
              sequential way.
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program.  If not, check <http://www.gnu.org/licenses/>.
 *****************************************************************************/

package components;

/**
 * @author Leandro Lei Minku
 *
 */
public class IncNegativeCorrelationLearning implements LearningAlgorithm {

	/************************************************************************************/
	// Incremental Negative Correlation Learning Algorithm
	// LOOK OUT!!! The NN of the ensemble should have its weights initialised.
	// Inputs: Ensemble, which is composed by size-1 neural nets that were already trained
	//                   plus a neural network that should be trained now.
	//         Dataset to be used to train one of the NNs of the ensemble.
	//         epochs: number os epochs that this NN should be trained
	//         LearningParameters
	//         newNetIndex: position of the new NN of the ensemble to be trained
	
	// This method will consider that the NN to be trained is in the last position of the
	// vector that represents the ensemble.
	public void learn(Ensemble ens, Dataset data, int epochs, LearningParameters param) {
		learn(ens, data, epochs, param, ens.size()-1);
	}
	
	public void learn(Ensemble ens, Dataset data, int epochs, LearningParameters param, int newNetIndex) {
		param.setEnsembleSize(ens.size());
		for(int e = 0; e < epochs; e++){
			//System.out.println("e="+e);
			data.shuffleData();
			//int[] correPerPattern = this.getNumberCorrectForEachPattern(data);
			for(int d = 0; d < data.getNoOfExamples(); d++){
				float[] inputs = data.getInputExample(d);
				float[] targets = data.getTargetExample(d);
				AVG avg = new AVG();
				
				// get the average output of the ensemble considering all the NNs of the
				// ensemble, including the NN that still was not trained.
				param.setAverageOutput(avg.combineOutputs(ens.getIndividualOutputs(inputs)));
				
				// Train only the NN that still was not trained
				ens.getNetwork(newNetIndex).learnDataExample(param,inputs,targets);
				
			}
			
			System.out.println(e + ", " + ens.test(data).getErrorRate());
		}

	}
	
	// Fernanda Li Minku
	// stop the training after maxEpochs or after maxConsecValGrow consecutive 
	// epochs with grow in the validation error
	
	public Ensemble learnUPEarlyStop(Ensemble ens, Dataset trainData, Dataset validationData, int maxConsecValGrow, int maxEpochs, LearningParameters param) {
		return learnUPEarlyStop(ens, trainData, validationData, maxConsecValGrow, maxEpochs, param, ens.size()-1);
	}
	
	public Ensemble learnUPEarlyStop(Ensemble ens, Dataset trainData, Dataset validationData, int maxConsecValGrow, int maxEpochs, LearningParameters param, int newNetIndex) {
		param.setEnsembleSize(ens.size());
		int consecValGrow = 0;
		Ensemble bestValidationEns = (Ensemble) ens.clone();
		float lastValidationError = ens.test(validationData).getErrorRate();
		float validationError = lastValidationError;
		float trainError;
		float testError;
		
		for(int e = 0; e < maxEpochs && consecValGrow < maxConsecValGrow; e++){
			//System.out.println("e="+e);
			trainData.shuffleData();
			//int[] correPerPattern = this.getNumberCorrectForEachPattern(data);
			for(int d = 0; d < trainData.getNoOfExamples(); d++){
				float[] inputs = trainData.getInputExample(d);
				float[] targets = trainData.getTargetExample(d);
				AVG avg = new AVG();
				
				// get the average output of the ensemble considering all the NNs of the
				// ensemble, including the NN that still was not trained.
				param.setAverageOutput(avg.combineOutputs(ens.getIndividualOutputs(inputs)));
				
				// Train only the NN that still was not trained
				ens.getNetwork(newNetIndex).learnDataExample(param,inputs,targets);
				
			}
			
			validationError = ens.test(validationData).getErrorRate();
			trainError = ens.test(trainData).getErrorRate();
			testError = ens.test(Globals.test).getErrorRate();
			
			if (validationError > lastValidationError)
				consecValGrow++;
			else 
				{
					consecValGrow = 0;
					bestValidationEns = (Ensemble) ens.clone();
				}
			
			lastValidationError = validationError;
			
			System.out.println(e + ", " + trainError + ", " + validationError + ", " + testError + ", " + consecValGrow);
		}
		
		return bestValidationEns;

	}
	
	// Fernanda Li Minku:
	// Train the ensemble NNs using the GL_alpha criterion for early stop (see Proben1 report).
	// The generalization loss start to be calculated only after a minimum training progress
	// is attained. If the training progress is attained and afterwards it is again 
	// bigger than the minimum training progress, the GL continues to be evaluated.
	// The GL considers only the validation error inside the strip size, to determine the
	// minimum validation error.
	// The training is also stopped if a pre-defined maximum number of epochs is attained.
	// If the minimal training erro inside a strip is 0, the training process is considered to
	// be 0.
	// BE CAREFUL!! The input ensemble ens will be modified, but it won't be the ensemble returned
	// by the learning algorithm, for it is not the one with the smallest validation error.
	// The one with the smallest validation error is the one that is returned by the function.
	// Inputs: 
	// ens: 			ensemble to be trained
	// train_data
	// validation_data: 
	// gl_alpha: 		parameter of the GL_alpha criterion for early stop.
	// max_epochs: if this maximum number is attained, the training is also stopped.
	//	 stripSize: strip size for GL_alpha
	// minProgress: minimum progress of the training to start considering the generalization loss to stop learning
	// LearningParameters
	//  newNetIndex: position of the new NN of the ensemble to be trained
	// Outputs:
	// The trained ensemble.
	
	public Ensemble learnGLEarlyStop(Ensemble ens, Dataset trainData, Dataset validationData, float glAlpha, float minProgress, int stripSize, int maxEpochs, LearningParameters param) {
		return this.learnGLEarlyStop(ens, trainData, validationData, glAlpha, minProgress, stripSize, maxEpochs, param, ens.size()-1);
	}
	
	public Ensemble learnGLEarlyStop(Ensemble ens, Dataset trainData, Dataset validationData, float glAlpha, float minProgress, int stripSize, int maxEpochs, LearningParameters param, int newNetIndex) {
		param.setEnsembleSize(ens.size());
		
		float trainError = ens.test(trainData).getErrorRate();
		float validationError = ens.test(validationData).getErrorRate();
		float testError;
		float minValidationError = validationError;
		Ensemble bestValidationEns = (Ensemble) ens.clone();
		float generalizationLoss = -1F; //100 * (validationError/minValidationError - 1);
		float trainingProgress = -1F;
		float stripTrainErrorSum = 0;
		float minStripTrainError = trainError;
		boolean minTrainingProgressAttained = false;
		
		int epoch = 0;
		
		while(epoch < maxEpochs  && generalizationLoss <= glAlpha) {
			trainData.shuffleData();
			//int[] correPerPattern = this.getNumberCorrectForEachPattern(data);
			for(int d = 0; d < trainData.getNoOfExamples(); d++){
				float[] inputs = trainData.getInputExample(d);
				float[] targets = trainData.getTargetExample(d);
				AVG avg = new AVG();
				
				// get the average output of the ensemble considering all the NNs of the
				// ensemble, including the NN that still was not trained.
				param.setAverageOutput(avg.combineOutputs(ens.getIndividualOutputs(inputs)));
				
				// Train only the NN that still was not trained
				ens.getNetwork(newNetIndex).learnDataExample(param,inputs,targets);
				
			}
			
			trainError = ens.test(trainData).getErrorRate();
			validationError = ens.test(validationData).getErrorRate();
			testError = ens.test(Globals.test).getErrorRate();
			
			// if it is the first epoch of the strip
			// reset the min strip train error and error sum at each new strip
			// and reset the min validation error
			if (epoch % stripSize == 0) {
				minStripTrainError = trainError;
				stripTrainErrorSum = trainError;
				
				// update the min validation error only if the GL5 already started to
				// be calculated
				//if (generalizationLoss != -1F) {
				// Always do that, for it is possible that the generalizationLoss never attain
				// the minimum value <---Minku12/01/07
					minValidationError = validationError;
					bestValidationEns = (Ensemble) ens.clone();
				//}
			}
			else // update min strip train error and error sum
			{
				if (minStripTrainError > trainError) {
					minStripTrainError = trainError;
				}
				
				stripTrainErrorSum += trainError;
				
				//	After we start calculating the generalizationLoss, update the minValidationError
				// at every epoch inside the strip
				//if ( (generalizationLoss != -1F) &&
				//	 (minValidationError >= validationError) )
				//{
				//Always do that, for it is possible that the generalizationLoss never attain
				// the minimum value <---Minku12/01/07
				if (minValidationError >= validationError)
				{
					minValidationError = validationError;
					bestValidationEns = (Ensemble) ens.clone();
				}
			}
			
			// if it is the last epoch of the strip, calculate the training progress
			if ((epoch+1) % stripSize == 0) {
				
				if (minStripTrainError != 0)
					trainingProgress = 1000 * (stripTrainErrorSum/(stripSize * minStripTrainError) - 1); 
				else trainingProgress = 0;
				
				if (trainingProgress <= minProgress)
					minTrainingProgressAttained = true;
				
				// calculate the generalization loss only if the training progress already
				// attained the minimim pre defined value
				if (minTrainingProgressAttained)
				{
					// if it's the first time I'm calculating the generalizationLoss
					if (generalizationLoss == -1F)
					{
						minValidationError = validationError;
						bestValidationEns = (Ensemble) ens.clone();
					}
					// update min validation error and the best validation error ens until now
					// only when we are in the last epoch of the strip
					/*else if (minValidationError >= validationError) {
						minValidationError = validationError;
						bestValidationEns = (Ensemble) ens.clone();
					}*/
				
					generalizationLoss = 100 * (validationError/minValidationError - 1);
				}

			}
			
			System.out.println(epoch + ", " + trainError + ", " + validationError + ", " + testError + ", " + minStripTrainError + ", " + minValidationError + ", " + trainingProgress + ", " + generalizationLoss);
			epoch++;
		}

		return bestValidationEns;
	}	

}
