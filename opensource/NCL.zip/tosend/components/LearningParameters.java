package components;



public class LearningParameters {
	
	public static final int STANDARD_BACKPROP = 0;
	public static final int NCL = 1;
	public static final int FITNESS_SHARE = 2;
	public static final int FITNESS_SHARE2 = 3;
	
	// Fernanda Li Minku
	public static final int NON_INCREMENTAL = 0;
	public static final int GROWING_INCREMENTAL = 1;
	public static final int FIXED_INCREMETNAL = 2;
	
	private int learningType;
	private float learnRate;
	
	private float penalty;
	private float[] averageOutput;
	private int ensembleSize;
	
	private float fitnessShare;
	
	public LearningParameters(float learnR){
		learningType = STANDARD_BACKPROP;
		learnRate = learnR;
	}
	
	public LearningParameters(float learnR, float pen, int ensSize){
		learningType = NCL;
		learnRate = learnR;
		penalty = pen;
		ensembleSize = ensSize;
	}
	
	// Fernanda Li Minku
	public LearningParameters(float learnR, int ensSize){
		learningType = STANDARD_BACKPROP;
		learnRate = learnR;
		ensembleSize = ensSize;
	}
	
	public LearningParameters(float learnR, float share){
		if(share == 1.0)
			learningType = FITNESS_SHARE;
		if(share == 2.0)
			learningType = FITNESS_SHARE2;
		learnRate = learnR;
		fitnessShare = share;
	}
	
	public int getLearningType(){
		return learningType;
	}
	
	public float getLearnRate(){
		return learnRate;
	}
	
	public float getPenalty(){
		return penalty;
	}
	public void setPenalty(float gamma){
		penalty = gamma;
	}
	
	public float[] getAverageOutput(){
		return averageOutput;
	}
	
	public void setAverageOutput(float[] avgOut){
		averageOutput = avgOut;
	}
	
	public int getEnsembleSize(){
		return ensembleSize;
	}
	
	public void setEnsembleSize(int s){
		ensembleSize = s;
	}
	
	public void setFitnessShare(float share){
		fitnessShare = share;
	}
	
	public float getFitnessShare(){
		return fitnessShare;
	}

}
