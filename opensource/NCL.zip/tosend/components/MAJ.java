package components;

public class MAJ extends CombinationScheme{
	
	
	public MAJ(){
		type = "MAJORITY_VOTE";
	}
	
	public float[] combineOutputs(float[][] ensembleOutputs){
		float[] combinedOutput = new float[ensembleOutputs[0].length];
		int[] votes = new int[combinedOutput.length];
		for(int network = 0; network < ensembleOutputs.length; network++){
			int highestOutput = ArrayHandler.maxCellLocation(ensembleOutputs[network]);
			votes[highestOutput]++;
		}
		int winner = ArrayHandler.maxCellLocation(votes);
		
		// Notice that in this case, the outputs of the ensemble will be only either 0
		// or 1. This will not be a problem to the learning phase, as in the learning 
		// phase we always consider the average combine method to determine f(n), in the
		// update rule! So, the MAJ or the WTA will be used only in the test phase, after
		// the training of the ensemble!!! That's why using MAJ with outputs either 0 or 1
		// is no problem for the learning
		// phase, in the time to backpropagate the error using MSE error with the penalty!!!
		combinedOutput[winner] = 1.0f;
		return combinedOutput;
	}

}
