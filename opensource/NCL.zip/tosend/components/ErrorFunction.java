/*
 * Created on 07-Jun-2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package components;

/**
 * @author pmd
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class ErrorFunction {
	protected String type;
	
	
	public abstract float getError(ErrorParameters param);
	public abstract float getDf_by_Da(ErrorParameters param);
	
	public static ErrorFunction createErrorFunction(String s){
		if(s.equals("MSE")){
			return new MeanSquareErrorFunction();
		}
		if(s.equals("NCL_MSE")){
			return new NCLMeanSquareErrorFunction();
		}
		return null;
	}
	
	public String getType(){
		return type;
	}
	
	public String toString(){
		return type;
	}
}
