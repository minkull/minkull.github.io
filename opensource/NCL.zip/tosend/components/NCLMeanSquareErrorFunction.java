package components;

public class NCLMeanSquareErrorFunction extends ErrorFunction{

protected MeanSquareErrorFunction mse;	

	// This NCL is according to the equation:
	// e_i = 1/N [1/2(f_i - d)^2 + gamma*p_i]
	// p_i = (f_i - f_bar)*Sum_jnoti(f_j - f_bar)
	// since (f_i - f_bar) = - Sum_jnoti(f_j - f_bar)
	// p_i = - (f_i - f_bar)^2
	// so...
	// e_i = 1/N [1/2(f_i - d)^2 - gamma*(f_i - f_bar)^2

	// differentiating to get de/df_i:
	// de/df_i = f_i - d - gamma[2(1-1/M)(f_i - f_bar)]
	// which is used to update the weights. It is converted to de/da = delta by
	// calculating df/da which is the differential of the transform function:
	// this is the differential of the node, for linear = 1, for sigmoid = f_i(1-f_i).
	


	public NCLMeanSquareErrorFunction(){
		type = "NCL_MSE";
		mse = new MeanSquareErrorFunction();
	}
	
	//ensAve must be set before called
	public float getError(ErrorParameters param) {
		float error = mse.getError(param) - (float)(param.penalty * (Math.pow(((param.estimate - param.ensAverage)*1d),2.0)));
		return error;
	}
	
	public float getMSE(ErrorParameters param){
		return mse.getError(param);
	}
	
	// returns p_i = (f_i - f_bar)*Sum_jnoti(f_j - f_bar) = - (f_i - f_bar)^2
	public float getPenalty(ErrorParameters param){
		return -1 * (float)((Math.pow(((param.estimate - param.ensAverage)*1d),2.0)));
	}
	
	public float getDf_by_Da(ErrorParameters param){
		float mseDifferential = mse.getDf_by_Da(param);
		float f_i = param.estimate;
		float f_bar = param.ensAverage;
		float gamma = param.penalty;
		float m = param.ensSize;
		float differential = 
			mseDifferential - ((float)((2*gamma*(1-(1/m))*(f_i - f_bar))));
		return differential;
	}
	
}
