/*
 * Created on 07-Jun-2005
 *
 * 
 */
package components;
import java.util.*;
/**
 * @author pmd
 *
 *An abstract class that represents a node in an MLP of undefined type.
 */
public abstract class Node implements Cloneable{
	
	//weights_vector weights;
	protected float[] weights;
	protected float bias;
	
	public String NODE_TYPE;
	
	public static final int LINEAR = 0;
	public static final int LOGISTIC = 1;
	
	
	public static Node createNode(String s){
		StringTokenizer st = new StringTokenizer(s,":");
		String t = st.nextToken();
		if(t.equals("linear") || t.equals(" linear")){
			return new LinearNode(st.nextToken(),st.nextToken());
		}
		if(t.equals("logistic")|| t.equals(" logistic")){
			return new LogisticNode(st.nextToken(),st.nextToken());
		}
		return null;
	}
	
	/*
	 * Abstract method that returns an output from a node given a set of inputs.
	 * @param inputs (float[]), the inputs to the node.
	 * @return (float), the output.
	 */
	public abstract float getOutput(float[] inputs);
	
	/*
	 * Abstract method that returns the differential of the output function.
	 * @param nodeOutput (float), the output of this node for a set of inputs.
	 * @return (float), the differential of the output.
	 */
	public abstract float getDf_by_Da(float nodeOutput);
	
	/**
	 * A protected method that sums the weighted inputs to the node.
	 * @param inputs (float[]), the inputs.
	 * @return (float) the sum of weighted inputs.
	 */
	protected float calculateSumOfWeightedInputs(float[] inputs){
		float sumOfWeightedInputs = 0;
		for(int i = 0; i < inputs.length; i++){
			sumOfWeightedInputs += (inputs[i]*weights[i]);
		}
		sumOfWeightedInputs += (1 * bias);
		return sumOfWeightedInputs;
	}
	
	/**
	 * A method to get the number of connections between this node and the previous layer.
	 * @return (int), the number of connections (weights).
	 */
	public int getNoOfConnections(){
		return weights.length;
	}
	
	/**
	 * initialises the weights to a random float, uniformly distributed about zero, with range 1, values between -0.5 and +0.5.
	 * @param range (int), the range about zero for the weights from -1/2*range to +1/2*range.
	 */
	public void uniformInitialWeights(int range){
		for(int i = 0; i < weights.length; i++){
			weights[i] = ((Globals.generalRand.nextFloat() - 0.5f) * range);
		}
		bias = ((Globals.generalRand.nextFloat() - 0.5f) * range);
	}
	
	public void setInitialWeights(float w){
		for(int i = 0; i < weights.length; i++){
			weights[i] = w;
		}
	}
	
	/**
	 * A method to get the weights_vector associated with this node. 
	 * @return (weights_vector), the weights of this node.
	 */
	public float[] getWeights(){
		return weights;
	}
	
	/**
	 * A method to set the weights_vector of this node.
	 * @param wV (weights_vector), the new weights.
	 */
	public void setWeights(float[] weightsArray){
		weights = weightsArray;
	}
	
	/**
	 * A method to set the weight of the ith connection.
	 * @param i (int), the index of the connection.
	 * @param w (float), the new weight.
	 */
	public void setWeight(int i, float w){
		weights[i] = w;
	}
	
	public float getWeight(int i){
		return weights[i];
	}
	
	/**
	 * A method to set the bias of the node.
	 * @param b (float), the new bias.
	 */
	public void setBias(float b){
		bias = b;
	}

	public void deltaRuleUpdate(float learnRate, float[] inputs, float delta){
		for(int i = 0; i < weights.length; i++){
			float w = weights[i];
			w = w + ((-1*learnRate)*delta*inputs[i]);
			weights[i] = w;
		}
		bias = bias + ((-1*learnRate)*delta*1);
	}
	
	public void gaussianMutateWeights(){
		for(int i = 0; i < weights.length; i++){
			float w = weights[i];
			w = w + (float)Globals.generalRand.nextGaussian();
			weights[i] = w;
		}
		bias = bias + (float)Globals.generalRand.nextGaussian();
	}

	/**
	 * A method that returns a String representation of the object.
	 * @return (String).
	 */
	public String toString(){
		String s = NODE_TYPE +":"+ ArrayHandler.arrayToString(weights)+ ":" + bias;
		return s;
	}
	
	/**
	 * Clones the object.
	 * @return (Object) 
	 */
	public Object clone(){
		Node newNode = null;
		try {
			newNode = (Node)super.clone();
			newNode.setWeights((float[])this.weights.clone());
		} 
		catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newNode;
		
	}
	
	
	
	
}