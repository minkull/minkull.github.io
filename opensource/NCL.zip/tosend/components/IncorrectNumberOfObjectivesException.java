package components;

public class IncorrectNumberOfObjectivesException extends Throwable{
private static final long serialVersionUID = 1L;
	
	int attemptedObjectives;
	String expectedObjectives;
	
	public IncorrectNumberOfObjectivesException(int att, String exp){
		super();
		attemptedObjectives = att;
		expectedObjectives = exp;
	}
	
	public String toString(){
		return "You have attempted to use a fitness function of type "
			+expectedObjectives+" to convert " + attemptedObjectives + "objectives.";
	}
}
