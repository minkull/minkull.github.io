package components;
import java.util.*;
/**
 * @author pmd
 *
 * A class to represent a linear node, where the output is simply the input.
 */
public class LinearNode extends Node {

	/**
	 * A constructor for a linear node with specified number of connections to the previous layer.
	 * @param noOfConnectionsToPreviousLayer (int), the number of connecions.
	 */
	public LinearNode(int noOfConnectionsToPreviousLayer){
		NODE_TYPE = "linear";
		weights = new float[noOfConnectionsToPreviousLayer];
	}
	
	public LinearNode(String w, String b){
		NODE_TYPE = "linear";
		StringTokenizer st = new StringTokenizer(w," ");
		weights = new float[st.countTokens()];
		for(int i = 0; i < weights.length; i++){
			weights[i] = new Float(st.nextToken()).floatValue();
		}
		bias = new Float(b).floatValue();
	}
	
	/** 
	 * A method to get the output of the node for a set of inputs. Output = weighted sum of inputs.
	 * @param inputs (float[]), the inputs to the node.
	 * @return (float), the output of the node.
	 */
	public float getOutput(float[] inputs) {
		float sumOfWeightedInputs = super.calculateSumOfWeightedInputs(inputs);
		return sumOfWeightedInputs;
	}
	
	/**
	 * A method to get the differential of the output of this node.
	 * = 1
	 * @param output (float), the output of this node for a given set of inputs.
	 * @return (float) the differential of the output for this node.
	 */
	public float getDf_by_Da(float nodeOutput){
		return 1;
	}

}
