package components;

public class UnknownNodeTypeException extends Throwable{

	private static final long serialVersionUID = 1L;
	
	int attemptedType;
	
	public UnknownNodeTypeException(int invalidType){
		super();
		attemptedType = invalidType;
	}
	
	public String toString(){
		return "The node type ("+attemptedType+") supplied is unknown. Please see node class for list of supported node types.";
	}

}
