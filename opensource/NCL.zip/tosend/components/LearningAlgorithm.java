package components;
public interface LearningAlgorithm {
	public abstract void learn(Ensemble ens, Dataset data, int epochs, LearningParameters param);
	public abstract Ensemble learnUPEarlyStop(Ensemble ens, Dataset trainData, Dataset validationData, int maxConsecValGrow, int maxEpochs, LearningParameters param);
	public abstract Ensemble learnGLEarlyStop(Ensemble ens, Dataset trainData, Dataset validationData, float glAlpha, float minProgress, int stripSize, int maxEpochs, LearningParameters param);
}
