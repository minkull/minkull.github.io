package components;

import java.util.*;


/**
 * A class that represents a multi layer perceptron with a single hidden layer.
 * @author Pete
 */
public class MLP implements Cloneable{
	
	protected int inputs;
	protected Layer hiddenLayer;
	protected Layer outputLayer;
	//the error function that will be used in training.
	protected ErrorFunction errorFunction;
	
	/**
	 * Constructor for a mlp with a single hidden layer.
	 * @param in (int), the number of input nodes.
	 * @param hid (int), the number of nodes in the hidden layer.
	 * @param out (int), the number of output nodes.
	 * @param e (error_function), the error function used in training the network.
	 */
	public MLP(int in, int hid, int out, ErrorFunction e){
		inputs = in;
		hiddenLayer = new Layer(hid);
		outputLayer = new Layer(out);		
		errorFunction = e;

	}
	
	public MLP(int in, Layer hid, Layer out, ErrorFunction e){
		inputs = in;
		hiddenLayer = hid;
		outputLayer = out;		
		errorFunction = e;
	}
	
	/**
	 * A method to fully connect the nodes in the network. Each node is connected to every node in the previous layer.
	 * node.LINEAR = 0.
	 * node.LOGISTIC = 1.
	 * @param hiddenLayerNodeType (int), the type of node in the hidden layer.
	 * @param outputLayerNodeType (int), the type of node in the output layer.
	 */
	public void connect(int hiddenLayerNodeType, int outputLayerNodeType) throws UnknownNodeTypeException{
		this.connectHiddenLayer(hiddenLayerNodeType);
		this.connectOutputLayer(outputLayerNodeType);
	}
	
	private void connectHiddenLayer(int typeOfUnit) throws UnknownNodeTypeException{
		if(typeOfUnit == Node.LINEAR){
			hiddenLayer.allLinearFullConnections(inputs);
		}
		else{
			if(typeOfUnit == Node.LOGISTIC){
				hiddenLayer.allLogisticFullConnections(inputs);
			}
			else{
				throw new UnknownNodeTypeException(typeOfUnit);
			}
		}
	}
	
	private void connectOutputLayer(int typeOfUnit) throws UnknownNodeTypeException{
		if(typeOfUnit == Node.LINEAR){
			outputLayer.allLinearFullConnections(hiddenLayer.size());
		}
		else{
			if(typeOfUnit == Node.LOGISTIC){
				outputLayer.allLogisticFullConnections(hiddenLayer.size());
			}
			else{
				throw new UnknownNodeTypeException(typeOfUnit);
			}
		}
	}
	
	public void uniformInitialise(int range){
		hiddenLayer.uniformInitialise(range);
		outputLayer.uniformInitialise(range);
	}
	
	public void setInitialise(float w){
		hiddenLayer.setInitialise(w);
		outputLayer.setInitialise(w);
	}
	
	
	public float[] getOutputs(float[] inputs){
		float[] outputs = outputLayer.getOutputs(this.getHiddenOutputs(inputs));
		return outputs;
	}
	
	private float[] getHiddenOutputs(float[] inputs){
		float[] hiddenOutputs = hiddenLayer.getOutputs(inputs);
		return hiddenOutputs;
	}
	
	private float[] getHiddenDeltas(float[] outputDeltas, float[] hiddenOutputs){
		float[] deltas = new float[hiddenLayer.size()];
		for(int hid = 0; hid < hiddenLayer.size(); hid++){
			float weightedSumOfOutputDeltas = 0;
			for(int out = 0; out < outputDeltas.length; out++){
				weightedSumOfOutputDeltas += (outputDeltas[out]*outputLayer.getNode(out).getWeight(hid));
			}
			deltas[hid] = weightedSumOfOutputDeltas * hiddenLayer.getNode(hid).getDf_by_Da(hiddenOutputs[hid]);
		}
		return deltas;
	}
	
	public void learnDataExample(LearningParameters param, float[] inputs, float[] targets){
		float[] hiddenOutputs = this.getHiddenOutputs(inputs);
		float[] outputDeltas = this.outputLayer.getOutputDeltas(errorFunction,param,hiddenOutputs,targets);
		float[] hiddenDeltas = this.getHiddenDeltas(outputDeltas,hiddenOutputs);
		hiddenLayer.updateWeights(param,inputs,hiddenDeltas);
		outputLayer.updateWeights(param,hiddenOutputs,outputDeltas);
	}
	
	public void learnDataset(int epochs, LearningParameters param, Dataset data, boolean verbose){
		
		for(int e = 0; e < epochs; e++){
			data.shuffleData();
			for(int d = 0; d < data.getNoOfExamples(); d++){
				this.learnDataExample(param,data.getInputExample(d),data.getTargetExample(d));
			}
		
			if (verbose)
				System.out.println(e + ", " + this.test(data).getErrorRate());
		}
	}
	
	// Fernanda Li Minku:
	// stop learning when the validation error grows for maxConsecValGrow consecutive epochs
	// or when the maximum number of epochs is attained.
	public MLP learnDatasetUPEarlyStop(Dataset trainData, Dataset validationData, int maxConsecValGrow, int maxEpochs, LearningParameters param) {
		
		int consecValGrow = 0;
		MLP bestValidationMLP = (MLP) this.clone();
		float lastValidationError = this.test(validationData).getErrorRate();
		float validationError = lastValidationError;
		float trainError;
		
		for(int e = 0; e < maxEpochs && consecValGrow < maxConsecValGrow; e++){
			trainData.shuffleData();
			for(int d = 0; d < trainData.getNoOfExamples(); d++){
				this.learnDataExample(param,trainData.getInputExample(d),trainData.getTargetExample(d));
			}
			
			validationError = this.test(validationData).getErrorRate();
			trainError = this.test(trainData).getErrorRate();
			
			if (validationError > lastValidationError)
				consecValGrow++;
			else 
				{
					consecValGrow = 0;
					bestValidationMLP = (MLP) this.clone();
				}
			
			lastValidationError = validationError;
			
			System.out.println(e + " " + trainError + " " + validationError + ", " + consecValGrow);
		}
		
		return bestValidationMLP;
	}
	
	// Fernanda Li Minku:
	// stop learning when the GL criterion is attained, only after the minimum training progress
	// is attained
	// or when the maximum number of epochs is attained.
	public MLP learnDatasetGLEarlyStop(Dataset trainData, Dataset validationData, float glAlpha, float minProgress, int stripSize, int maxEpochs, LearningParameters param) {
		
		float trainError = this.test(trainData).getErrorRate();
		float validationError = this.test(validationData).getErrorRate();
		float minValidationError = validationError;
		MLP bestValidationMLP = (MLP) this.clone();
		float generalizationLoss = -1F; //100 * (validationError/minValidationError - 1);
		float trainingProgress = -1F;
		float stripTrainErrorSum = 0;
		float minStripTrainError = trainError;
		boolean minTrainingProgressAttained = false;
		
		int epoch = 0;
		
		while(epoch < maxEpochs && generalizationLoss <= glAlpha) {
			trainData.shuffleData();
			for(int d = 0; d < trainData.getNoOfExamples(); d++){
				this.learnDataExample(param,trainData.getInputExample(d),trainData.getTargetExample(d));
			}
			
			trainError = this.test(trainData).getErrorRate();
			validationError = this.test(validationData).getErrorRate();
			
			// if it is the first epoch of the strip
			// reset the min strip train error and error sum at each new strip
			// and reset the min validation error
			if (epoch % stripSize == 0) {
				minStripTrainError = trainError;
				stripTrainErrorSum = trainError;
				
				// update the min validation error only if the GL5 already started to
				// be calculated
				if (generalizationLoss != -1F) { 
					minValidationError = validationError;
					bestValidationMLP = (MLP) this.clone();
				}
			}
			else // update min strip train error and error sum
			{
				if (minStripTrainError > trainError) {
					minStripTrainError = trainError;
				}
				
				stripTrainErrorSum += trainError;
				
				//	After we start calculating the generalizationLoss, update the minValidationError
				// at every epoch inside the strip
				if ( (generalizationLoss != -1F) &&
					 (minValidationError >= validationError) )
				{
					minValidationError = validationError;
					bestValidationMLP = (MLP) this.clone();
				}
			}
			
						
			// if it is the last epoch of the strip, calculate the training progress
			if ((epoch+1) % stripSize == 0) {
				
				if (minStripTrainError != 0)
					trainingProgress = 1000 * (stripTrainErrorSum/(stripSize * minStripTrainError) - 1); 
				else trainingProgress = 0;
				
				if (trainingProgress <= minProgress)
					minTrainingProgressAttained = true;
				
				// calculate the generalization loss only if the training progress already
				// attained the minimim pre defined value
				if (minTrainingProgressAttained)
				{
					// if it's the first time I'm calculating the generalizationLoss
					if (generalizationLoss == -1F)
					{
						minValidationError = validationError;
						bestValidationMLP = (MLP) this.clone();
					}
					
					// update min validation error and the best validation error ens until now
					// only when we are in the last epoch of the strip
					/*else if (minValidationError >= validationError) {
						minValidationError = validationError;
						bestValidationEns = (Ensemble) ens.clone();
					}*/
					
					generalizationLoss = 100 * (validationError/minValidationError - 1);
				}
				
					
			}
			
			System.out.println(epoch + ", " + trainError + ", " + validationError + ", " + minStripTrainError + ", " + minValidationError + ", " + trainingProgress + ", " + generalizationLoss);
			epoch++;
		}
		
		return bestValidationMLP;
			
		
	}
	
	public Object clone(){
		try {
			MLP newNet = (MLP)super.clone();
			newNet.hiddenLayer = (Layer)this.hiddenLayer.clone();
			newNet.outputLayer = (Layer)this.outputLayer.clone();
			return newNet;
		} 
		catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	public int getPredictedClass(float[] input){
		int prediction = -1;
		float[] output = getOutputs(input);
		prediction = ArrayHandler.maxCellLocation(output);
		return prediction;
	}
	
	public boolean isPredictionCorrect(float[]input, float[] target){
		int classPrediction = getPredictedClass(input);
		int targetPrediction = ArrayHandler.maxCellLocation(target);
		if(classPrediction == targetPrediction)
			return true;
		else
			return false;
	}
	
	public Layer getHiddenLayer(){
		return hiddenLayer;
	}
	
	public Layer getOutputLayer(){
		return outputLayer;
	}
	
	public Results test(Dataset data){
		Results res = new Results(data.getNoOfClasses(), data.getNoOfExamples()); // <---Fer07/02/07 Insertion of NoOfExamples
		for(int i = 0; i < data.getNoOfExamples(); i++){
			float[] out = this.getOutputs(data.getInputExample(i));
			res.testExample(out,data.getTargetExample(i), i); // <---Fer07/02/07 Insertion of the last i
		}
		return res;
	}
	
	//across entire dataset, averaged over outputs as well
	public float getMeanSquareError(Dataset data){
		float avgError = 0;
		for(int i = 0; i < data.getNoOfExamples(); i++){
			float[] in = data.getInputExample(i);
			float[] tar = data.getTargetExample(i);
			float[] out = this.getOutputs(in);
			float avgForThisExample = 0;
			for(int j = 0; j < out.length; j++){
				ErrorParameters param = new ErrorParameters(out[j],tar[j]);
				avgForThisExample += errorFunction.getError(param);
			}
			avgForThisExample = avgForThisExample / (out.length*1f);
			avgError += avgForThisExample;
		}
		avgError = avgError/(1*data.getNoOfExamples());
		return avgError;
	}
	
	//across entire datset.
	public float getErrorRate(Dataset data){
		float errorRate = 0;
		int incorrect = 0;
		for(int i = 0; i < data.getNoOfExamples(); i++){
			boolean correct = isPredictionCorrect(data.getInputExample(i), data.getTargetExample(i));
			if(correct == false){
				incorrect ++;
			}
			
		}
		errorRate = incorrect / (1f* data.getNoOfExamples());
		return errorRate;
	}
	
	//this is returning the average across the output nodes
	public float getNCLError(float[] in, float[] tar, float pen, float[] ensOut, int ensSize){
		float nclError = 0;	
		float[] out = this.getOutputs(in);
		for(int i = 0; i < tar.length; i++){
			ErrorParameters param = new ErrorParameters(out[i],tar[i],ensOut[i],pen,ensSize);
			nclError += errorFunction.getError(param);
		}
		nclError = nclError / tar.length;
		return nclError;
	}
	
	public String toString(){
		String s = "";
		s = s + "Hidden Layer{"+hiddenLayer.toString()+"}";
		s = s + "Output Layer{"+outputLayer.toString()+"}";
		return s;
	}
	
	public String toSaveString(){
		String s = "["+errorFunction.toString()+"]"+"["+inputs+"]"+hiddenLayer.toString()+outputLayer.toString();
		return s;
	}
	
	public MLP(String s){
		StringTokenizer myTokenizer = new StringTokenizer(s,"[]");
		errorFunction = ErrorFunction.createErrorFunction(myTokenizer.nextToken());
		inputs = new Integer(myTokenizer.nextToken()).intValue();
		hiddenLayer = new Layer(myTokenizer.nextToken());
		outputLayer = new Layer(myTokenizer.nextToken());		
		
		
	}
}
