/*
 * results.java
 *
 * Created on 28 April 2005, 17:54
 */

package components;


//import java.io.*;
//import java.sql.*;

/**
 * A class to record the results of a classification test over a set of data.
 */
public class Results{

private int numberTested;
private int numberCorrect;
private int[][] confusion;  //a matrix wher the columns are the ens class
                            //and the rows the target class.
private float se;
private int [] examplesTest; // a vector with a position to each of the examples used in the test. The position contains 1 if the example was correctly classified, 0 if it was not correctly classified and -1 if it wasn't classified yet. <---Fer07/02/07
  

/**
 * A constructor to create a results object.
 */
  public Results(int numberOfClasses, int numberOfExamples){ // Insertion of numberOfExamples <---Fer07/02/07
    numberTested = 0;
    numberCorrect = 0;
    confusion = new int[numberOfClasses][];
    for(int i=0; i<numberOfClasses; i++){
        confusion[i] = new int[numberOfClasses];
        for(int j = 0; j<numberOfClasses; j++){
            confusion[i][j] = 0;
        }
    }
    se = 0;
    examplesTest = new int[numberOfExamples]; // Insertion of numberOfPatterns <---Fer07/02/07
    for (int i=0; i<numberOfExamples; i++)
      examplesTest[i] = -1;
    
    

}

public void setNumberTested(int n){
    numberTested = n;
}

public int getNumberTested(){
    return numberTested;
}

public void setNumberCorrect(int c){
    numberCorrect = c;
}

public int getNumberCorrect(){
    return numberCorrect;
}

public float getErrorRate(){
    return 1-(numberCorrect/(1f*numberTested));
}

public void setConfusion(int pred, int targ, int value){
    confusion[targ][pred] = value;
}

public int getConfusion(int pred, int targ, int value){
    return confusion[targ][pred];
}

public float getSumSquareError(){
    return se/(numberTested*1f);
}

public float getMeanSquareError(){
    return getSumSquareError()/(confusion.length*1f);
}

public void testExample(float[] output, float[] target, int exampleNumber){ // Insertion of exampleNumber <---Fer07/02/07

  examplesTest[exampleNumber]++; // Insertion of exampleNumber <---Fer07/02/07
  
    for(int i = 0; i < output.length; i++){
    	float temp = target[i]-output[i];
        se = se + (temp*temp);
    }
    int selectedOutput  = ArrayHandler.maxCellLocation(output);
    int selectedTarget = ArrayHandler.maxCellLocation(target);
    numberTested++; 
    confusion[selectedTarget][selectedOutput]++;
    if ( selectedOutput == selectedTarget ){
        numberCorrect++;
	examplesTest[exampleNumber]++; // Insertion of exampleNumber <---Fer07/02/07
    }
}

public String toScreenPrintString(int testOrTrain){
    String testName = "";
    if(testOrTrain == 0)
        testName = testName + "TRAINING";
    else 
        testName = testName + "TESTING2";
    
    	
    String s = "\n-----------------------------------\n"+ testName+"\n";
    s = s + "Set size = " + numberTested + "\n";
    s = s + "MSE = " + getMeanSquareError() + "\n";
    s = s + "xError Rate = " + (1-(numberCorrect/(numberTested*1d))) + "\n";
    s = s+ "\t |\t";
    for(int i=0; i<confusion.length; i++){
        s = s + i+ "|\t";
    }
    for(int i=0; i<confusion.length; i++){
        s = s + "\n\t"+i+"|";
        for(int j=0; j<confusion.length;j++){
            s = s + "\t"+confusion[i][j]+"|";
        }
    }

    // <---Fer07/02/07 Insertion of the examples tested
    s = s + "\n\nEXAMPLES TESTED (-1 = not tested, 0 = incorrect classified, 1 = correct classified):\n";
    for (int i=0; i<examplesTest.length; i++)
      s = s + examplesTest[i] + "\n";
    
    return s;
}

//public String toFilePrintString(int testOrTrain){
//    String testName = eencl_project.globals.currentExperiment + "," + eencl_project.globals.currentFold + "," + testOrTrain;
//    String s = "\n"+testName+","+  (numberCorrect/(numberTested*1d))+",";
//    for(int i=0; i<confusion.length; i++){
//        for(int j=0; j<confusion.length;j++){
//            s = s + confusion[i][j]+",";
//        }
//    }
//    return s;
//}
/*
public void outputToFile(String fileName, int testOrTrain){
    try{
      FileWriter out = new FileWriter(fileName, true);
      String s = toFilePrintString(testOrTrain);
      out.write(s);
      out.close(); 
    }
    catch(IOException e){
      System.out.print("\nIO Exception\n" + e +"\nUnable to write to file");
    }  
}*/

//public String toSQLInsertString(String date, int testOrTrain,int combination){
//	String sql = "INSERT INTO results VALUES('"+date+"',";
//	sql = sql + eencl_project.globals.currentExperiment +"," + eencl_project.globals.currentFold + ","+combination+"," + testOrTrain + ",";
//	sql = sql + (numberCorrect/(numberTested*1d))+",";
//	for(int i=0; i<confusion.length; i++){
//        for(int j=0; j<confusion.length;j++){
//            sql = sql + confusion[i][j];
//            if(i != (confusion.length -1) || j != (confusion.length -1)){
//            	sql = sql + ",";
//            }
//        }
//    }
//	sql = sql + ");";
//	return sql;
//}
//
//public void outputToDatabase(String date, Connection con, int testOrTrain, int combination){
//	String sql = "";
//	try{
//		sql = this.toSQLInsertString(date, testOrTrain,combination);
//		Statement stmt = con.createStatement();
//		stmt.executeUpdate(sql);
//	}
//	catch(SQLException e2){
//    	System.err.println( "SQLException\n" + e2 + "\n"+sql);
//    }
//}

}
