package components;
import java.util.*;


//a class for a standard hidden or output layer in MLP. Not a soft-max layer.
public class Layer extends Vector implements Cloneable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Layer(int size){
		super(size);
	}
	
	public void allLinearFullConnections(int connections){
		for(int i = 0; i < this.capacity(); i++){
			this.add(i,new LinearNode(connections));
		}
	}
	
	public void allLogisticFullConnections(int connections){
		for(int i = 0; i < this.capacity(); i++){
			this.add(i,new LogisticNode(connections));
		}
	}
	
	public void uniformInitialise(int range){
		for(int i = 0; i < this.size(); i++){
			((Node)(this.get(i))).uniformInitialWeights(range);
		}
	}
	
	public void setInitialise(float w){
		for(int i = 0; i < this.size(); i++){
			((Node)(this.get(i))).setInitialWeights(w);
		}
	}
	
	public Node getNode(int n){
		return (Node)this.get(n);
	}
	
	public void setWeight(int node, int weight, float value){
		this.getNode(node).setWeight(weight,value);
	}
	
	public void setBias(int node, float value){
		this.getNode(node).setBias(value);
	}
	
	public Object clone(){
		Layer newLayer = (Layer)super.clone();
		for(int i = 0; i < this.size(); i++){
			newLayer.set(i,(Node)(this.getNode(i)).clone());
		}
		return newLayer;
	}
	
	public float[] getOutputs(float[] inputs){
		float[] outputs = new float[this.size()];
		for(int i = 0; i < this.size(); i++){
			outputs[i] = this.getNode(i).getOutput(inputs);
		}
		return outputs;
	}
	
	public float[] getOutputDeltas(ErrorFunction e, LearningParameters param, float[] hiddenOutputs, float[] targets){
		float[] deltas = new float[this.size()];
		float[] outputs = this.getOutputs(hiddenOutputs);

		for(int i = 0; i < deltas.length; i++){
			if(param.getLearningType() == param.STANDARD_BACKPROP ){
				deltas[i] = e.getDf_by_Da(new ErrorParameters(outputs[i],targets[i])) * this.getNode(i).getDf_by_Da(outputs[i]);
			}
			if(param.getLearningType() == param.NCL){
				deltas[i] = e.getDf_by_Da(new ErrorParameters(outputs[i],targets[i],param.getAverageOutput()[i],param.getPenalty(),param.getEnsembleSize())) * this.getNode(i).getDf_by_Da(outputs[i]);
			}
			if(param.getLearningType() == param.FITNESS_SHARE){
				deltas[i] = param.getFitnessShare() * e.getDf_by_Da(new ErrorParameters(outputs[i],targets[i])) * this.getNode(i).getDf_by_Da(outputs[i]);
			}
		}
		return deltas;
	}
	
	public void updateWeights(LearningParameters param, float[] inputs, float[] deltas){
		for(int i = 0; i < this.size(); i ++){
			this.getNode(i).deltaRuleUpdate(param.getLearnRate(),inputs,deltas[i]);
		}
	}
	
	public void gaussianMutateWeights(){
		for(int i = 0; i < this.size(); i++){
			this.getNode(i).gaussianMutateWeights();
		}
	}
	
	public Layer(String s){
		super();
		StringTokenizer myTokenizer = new StringTokenizer(s,",");
		int size = myTokenizer.countTokens();
		for(int i = 0; i < size; i++){
			this.add(i,Node.createNode(myTokenizer.nextToken()));
		}
	}
	
	
	
}