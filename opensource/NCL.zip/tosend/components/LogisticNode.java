package components;

import java.util.StringTokenizer;

/**
 * @author pmd
 *
 * A class that represents a logistic node.
 * 
 * @extends node
 */
public class LogisticNode extends Node implements Cloneable{

	
	
	/**
	 * Constructor for a logistic node with the specified number of connections to previous layer.
	 * @param noOfConnectionsToPreviousLayer (int), the number of connections.
	 */
	public LogisticNode(int noOfConnectionsToPreviousLayer){
		NODE_TYPE = "logistic";
		weights = new float[noOfConnectionsToPreviousLayer];
	}
	
	public LogisticNode(String w, String b){
		NODE_TYPE = "logistic";
		StringTokenizer st = new StringTokenizer(w," ");
		weights = new float[st.countTokens()];
		for(int i = 0; i < weights.length; i++){
			weights[i] = new Float(st.nextToken()).floatValue();
		}
		bias = new Float(b).floatValue();
	}
	
	/**
	 * A method that passes the inputs through a logistic function to get an output for the node.
	 * @param inputs (double[]), the inputs to the node.
	 * @return (double), the output of the unit.
	 */
	public float getOutput(float[] inputs) {
		float sumOfWeightedInputs = super.calculateSumOfWeightedInputs(inputs);
		return (float)(1 / (1 + Math.exp(-1*sumOfWeightedInputs)));
	}
	
	/**
	 * A method to get the differential of the output of this node.
	 * = output * (1 - output)
	 * @param output (double), the output of this node for a given set of inputs.
	 * @return (double) the differential of the output for this node.
	 */
	public float getDf_by_Da(float nodeOutput){
		return nodeOutput * (1-nodeOutput); 
	}
	
	
	
}
