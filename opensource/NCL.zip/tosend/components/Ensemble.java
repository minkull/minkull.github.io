package components;
import java.io.*;
import java.util.*;

//a class for building an ensemble where the networks learn individually (sequentially).
public class Ensemble extends Vector implements Cloneable{

	private static final long serialVersionUID = 1L;
	
	protected CombinationScheme combiner;
	protected LearningAlgorithm learner;
	
	public Ensemble(int size, CombinationScheme c, LearningAlgorithm l){
		super(size);
		combiner = c;
		learner = l;
	}
	
	// Fernanda Li Minku:
	// This constructor makes that the vector's capacity is incrememted by
	// inc_capacity, if it's necessary to increase its capacity.
	// Usually it will be necessary to increase the capacity of the vector that
	// represents the NNs of the ensemble when we are working with incremental NCL, because
	// we need to increase the number of NNs in the ensemble according with the number of 
	// datasets received.
	
	public Ensemble(int size, int incCapacity, CombinationScheme c, LearningAlgorithm l){
		super(size, incCapacity);
		combiner = c;
		learner = l;
	}
	
	public Ensemble(int size, CombinationScheme c, LearningAlgorithm l,MLP template){
		super(size);
		combiner = c;
		learner = l;
		for(int i = 0; i < size; i++){
			super.add(i,template.clone());
		}
	}
	
	
	// Fernanda Li Minku:
	//	 This constructor makes that the vector's capacity is incrememted by
	// inc_capacity, if it's necessary to increase its capacity.
	// Usually it will be necessary to increase the capacity of the vector that
	// represents the NNs of the ensemble when we are working with incremental NCL, because
	// we need to increase the number of NNs in the ensemble according with the number of 
	// datasets received.	
	public Ensemble(int size, int incCapacity, CombinationScheme c, LearningAlgorithm l,MLP template){
		super(size, incCapacity);
		combiner = c;
		learner = l;
		for(int i = 0; i < size; i++){
			super.add(i,template.clone());
		}
	}
	
	public void populate(int in, int hid, int out, ErrorFunction e) throws UnknownNodeTypeException{
		populate(in,hid,out,Node.LOGISTIC,Node.LOGISTIC,e);
	}
	
	public void populate(int in, int hid, int out, int hidType, int outType, ErrorFunction e) throws UnknownNodeTypeException{
		for(int i = 0; i < this.capacity(); i++){
			MLP net = new MLP(in,hid,out,e);
			net.connect(hidType,outType);
			this.add(i,net);
		}
	}
	
	/*
	 * Fernanda Li Minku: 
	 * Increase the size of the ensemble, adding 1 NN.
	 * LOOK OUT!!! This function does not initialize the weights of the MLP!!!
	 * To do that you will have to call somethings like net.uniformInitialise(range);
	 * Inputs: in, hid, out: number of inputs/hidden/outputs of the MLP
	 *         hidType/outType: type of the activation function of the hidden/output units
	 *         ErrorFunction
	 *         range: the range of values to do the uniform inicialization of the weights.
	 * Outputs: index of the position where the new MLP was inserted.
	*/
	public int addMLP(int in, int hid, int out, int hidType, int outType, ErrorFunction e) throws UnknownNodeTypeException{
		
		// Ensure that the number of NNs on the ensemble can be the number used now 
		// plus 1, as we have to add 1 NN into the ensemble.
		this.ensureCapacity(this.size() + 1);
		
		MLP net = new MLP(in,hid,out,e);
		net.connect(hidType,outType);
		this.add(net);
		
		return this.size()-1;
		
	}
	
	public void uniformInitialise(int range){
		for(int i = 0; i < this.size(); i++){
			this.getNetwork(i).uniformInitialise(range);
		}
	}
	
	public MLP getNetwork(int i){
		return (MLP)(this.get(i));
	}
	
	public LearningAlgorithm getLearningAlgorithm(){
		return learner;
	}
	
	public float[] getOutput(float[] inputs){
		float[][] outputs = this.getIndividualOutputs(inputs);
		float[] combinedOutput = combiner.combineOutputs(outputs);
		return combinedOutput;
	}
	
	public int getPrediction(float[] inputs){
		return ArrayHandler.maxCellLocation(this.getOutput(inputs));
	}
	
	public float[][] getIndividualOutputs(float[] inputs){
		float[][] outputs = new float[this.size()][];
		for(int net = 0; net < this.size(); net++){
			outputs[net] = this.getNetwork(net).getOutputs(inputs);
		}
		return outputs;
	}

	
	public float[][][] getIndividualOutputs(Dataset data){
		float[][][] outputs = new float[data.getNoOfExamples()][][];
		for(int d = 0; d < outputs.length; d++){
			outputs[d] = getIndividualOutputs(data.getInputExample(d));
		}
		return outputs;
	}
	
	public boolean[][] getNetToPatternCorrectMatrix(Dataset data){
		boolean[][] correctMatrix = new boolean[data.getNoOfExamples()][];
		for(int d = 0; d < data.getNoOfExamples();d++){
			correctMatrix[d] = new boolean[this.size()];
			for(int net = 0; net < this.size(); net++){
				correctMatrix[d][net] = this.getNetwork(net).isPredictionCorrect(data.getInputExample(d),data.getTargetExample(d));
			}
		}
		return correctMatrix;
	}
	
	public float[] getMSE(Dataset data){
		float[] mse = new float[data.getNoOfClasses()];
		for(int i = 0; i < data.getNoOfExamples(); i++){
			float[] est = this.getOutput(data.getInputExample(i));
			float[] tar = data.getTargetExample(i);
			for(int node = 0; node < mse.length; node++){
				mse[node] = mse[node] + (float)Math.pow((est[node] - tar[node]),2);
			}
			
			
		}
		for(int node = 0; node < mse.length; node++){
			mse[node] = mse[node] / (1f*data.getNoOfExamples());
		}
		return mse;
	}
	
	public float getAvgMSE(Dataset data){
		float[] mse = getMSE(data);
		float avg = 0;
		for(int i = 0; i < mse.length; i++){
			avg = avg+mse[i];
		}
		avg = avg / (1f*mse.length);
		return avg;
	}
	
	public float getAvgNCLPenalty(Dataset data){
		float pen = 0;
		NCLMeanSquareErrorFunction nclFunct = new NCLMeanSquareErrorFunction();		
		for(int d = 0; d < data.getNoOfExamples(); d++){
			AVG avg = new AVG();
			float[] ensAvg = avg.combineOutputs(this.getIndividualOutputs(data.getInputExample(d)));
			for(int net = 0; net < this.size(); net++){
				float[] est = this.getNetwork(net).getOutputs(data.getInputExample(d));
				float[] tar = data.getTargetExample(d);
				for(int node = 0; node < data.getNoOfClasses(); node++){
					ErrorParameters param = new ErrorParameters(est[node],tar[node],ensAvg[node],0,this.size());
					pen = pen + nclFunct.getPenalty(param);
				}			
			}	
		}
		pen = pen / (this.size()*data.getNoOfClasses()*data.getNoOfExamples()*1f);
		return pen;
	}
	
	public void learn(int epochs, LearningParameters param, Dataset data){
		learner.learn(this,data,epochs,param);
	}
	
	// Fernanda Li Minku:
	// This method makes the NN to be trained (in the case of incremental learning) be
	// the last NN of the ensemble.
	public Ensemble learnUPEarlyStop(Dataset trainData, Dataset validationData, int maxConsecValGrow, int maxEpochs, LearningParameters param) {
		return learner.learnUPEarlyStop(this, trainData, validationData, maxConsecValGrow, maxEpochs, param);
	}

	// Fernanda Li Minku:
	// This method makes the NN to be trained (in the case of incremental learning) be
	// the last NN of the ensemble.
	public Ensemble learnGLEarlyStop(Dataset trainData, Dataset validationData, float glAlpha, float minProgress, int stripSize, int maxEpochs, LearningParameters param){
		return learner.learnGLEarlyStop(this, trainData, validationData, glAlpha, minProgress, stripSize, maxEpochs, param);
	}
	
	public int[] getNumberCorrectForEachPattern(Dataset data){
		int[] numberCorrect = new int[data.getNoOfExamples()];
		for(int i = 0; i < numberCorrect.length; i++){
			for(int j = 0; j < this.size(); j++){
				if(this.getNetwork(j).isPredictionCorrect(data.getInputExample(i),data.getTargetExample(i))){
					numberCorrect[i] ++;
				}
			}
		}
		return numberCorrect;
	}
	
	public int getNumberCorrectForSinglePattern(float[] in, float[] out){
		int numberCorrect = 0;
			for(int j = 0; j < this.size(); j++){
				if(this.getNetwork(j).isPredictionCorrect(in,out)){
					numberCorrect ++;
				}
			}
		return numberCorrect;
	}
	
	
	public CombinationScheme getCombinationScheme(){
		return combiner;
	}
	
	public void setCombinationScheme(CombinationScheme comb){
		combiner = comb;
	}
	public Results test(Dataset data){
	  Results res = new Results(data.getNoOfClasses(), data.getNoOfExamples()); // <---Fer07/02/07 Insertion of NoOfExamples
		for(int i = 0; i < data.getNoOfExamples(); i++){
			float[] outputs = this.getOutput(data.getInputExample(i));
			res.testExample(outputs,data.getTargetExample(i), i); // <---Fer07/02/07 Insertion of the last i
		}
		return res;
	}

  public void testAndPrintEachMLP(Dataset test_data, Dataset train_data, Dataset validation_data) // <---Fer07/02/07 New method
  {
    Results res;

    for(int net = 0; net < this.size(); net++)
    {
    	
    	System.out.println("MLP " + net + "\n");
    	
    	// <---Fer14/02/07 added to test train and validation
        res = new Results(train_data.getNoOfClasses(), train_data.getNoOfExamples());
        for(int i = 0; i < train_data.getNoOfExamples(); i++)
        {
        	float[] outputs = this.getNetwork(net).getOutputs(train_data.getInputExample(i));
        	res.testExample(outputs,train_data.getTargetExample(i), i);
  	
        }
        System.out.println("xTrain error: " + res.getErrorRate());
    	
        // <---Fer14/02/07 added to test train and validation
        res = new Results(validation_data.getNoOfClasses(), validation_data.getNoOfExamples());
        for(int i = 0; i < validation_data.getNoOfExamples(); i++)
        {
        	float[] outputs = this.getNetwork(net).getOutputs(validation_data.getInputExample(i));
        	res.testExample(outputs,validation_data.getTargetExample(i), i);
        }
        System.out.println("xValidation error: " + res.getErrorRate());    
        
        
        
      res = new Results(test_data.getNoOfClasses(), test_data.getNoOfExamples());
      for(int i = 0; i < test_data.getNoOfExamples(); i++)
      {
    	  float[] outputs = this.getNetwork(net).getOutputs(test_data.getInputExample(i));
    	  res.testExample(outputs,test_data.getTargetExample(i), i);
	
      }     
      System.out.println(res.toScreenPrintString(1)); 
      
       
    }
  }
   
    

	public float getNCLError(int network, Dataset data, float pen){
		float avgNCLError = 0;
		for(int d = 0; d < data.getNoOfExamples(); d++){
			float[] inputs = data.getInputExample(d);
			float[] targets = data.getTargetExample(d);
			AVG avg = new AVG();
			float[][] individualOutputs = this.getIndividualOutputs(inputs);
			float[] avg_out = avg.combineOutputs(individualOutputs);
			avgNCLError += this.getNetwork(network).getNCLError(inputs,targets,pen,avg_out,this.size());
		}
		avgNCLError = avgNCLError / (1f*data.getNoOfExamples());
		return avgNCLError;
	}
	
	public String toString(){
		String s = "";
		for(int i = 0; i < this.size(); i++){
			s = s + "\nNETWORK "+i+"\n" + this.getNetwork(i).toString();
		}
		return s;
	}
	
	public String toSaveString(){
		String s = "Ensemble,"+this.getCombinationScheme().toString()+","+this.size()+"\n";
		s = s + "[Error][Ind Penalty?][Inputs][Hidden Nodes][Output Nodes]\n";
		for(int i = 0; i < this.size(); i++){
			s = s + this.getNetwork(i).toSaveString()+"\n";
		}
		return s;
	}
	
	public static Ensemble createEnsemble(BufferedReader br)throws IOException{
		String titleLine = br.readLine();
		StringTokenizer st = new StringTokenizer(titleLine,",");
		if(st.nextToken().equals("Ensemble")){
			CombinationScheme comb = CombinationScheme.createCombinationScheme(st.nextToken());
			//column headers
			br.readLine();
			return new Ensemble(new Integer(st.nextToken()).intValue(),comb,br);
		}
		else throw new IOException();
	}
	
	public Ensemble(int s, CombinationScheme c, BufferedReader br) throws IOException{
		super(s);
		combiner = c;
		for(int i = 0; i < s; i++){
			this.add(new MLP(br.readLine()));
		}
	}
	
	public Object clone(){
		Ensemble newEns = (Ensemble)super.clone();
		for(int i =0; i < newEns.size(); i++){
			//System.out.pritnln("i="+i)
			newEns.set(i,(MLP)this.getNetwork(i).clone());
		}
		newEns.setCombinationScheme(this.getCombinationScheme());
		return newEns;

	}
	
	
}
