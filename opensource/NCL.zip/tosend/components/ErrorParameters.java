package components;

public class ErrorParameters {
	
	public int errorType;
	public static final int MSE = 0;
	public static final int NCL_MSE = 1;
	
	public float estimate;
	public float target;
	
	public float ensAverage;
	public float penalty;
	public float ensSize;
	public float sumFjMinusFbar;
	
	public ErrorParameters(float est, float tar){
		errorType = MSE;
		estimate = est;
		target = tar;
	}
	
	public ErrorParameters(float est, float tar, float avg, float pen, int eSize){
		errorType = NCL_MSE;
		estimate = est;
		target = tar;
		ensAverage = avg;
		penalty = pen;
		ensSize = eSize;
	}
}
