package components;

import java.io.*;
import java.util.*;


public class Dataset{
    
float[][] inputs;
float[][] targets;
int noOfExamples;
int noOfInputValues;
int noOfClasses;

/**
 * Costructor to make a dataset object, which holds arrays of arrays of inputs
 * and target values.
 *
 * @param in, the set of inputs (float[][])
 * @param t, the set of targets (float[][])
 */
public Dataset(float[][] in, float[][] t){
    inputs = in;
    targets = t;
    noOfExamples = inputs.length;
    noOfInputValues = inputs[0].length;
    noOfClasses = targets[0].length;
}

public Dataset(Vector in, Vector tar){
	inputs = new float[in.size()][];
	targets = new float[tar.size()][];
	for(int i = 0; i < in.size(); i++){
		inputs[i] = (float[])in.get(i);
		targets[i] = (float[])tar.get(i);
	}
	noOfExamples = inputs.length;
    noOfInputValues = inputs[0].length;
    noOfClasses = targets[0].length;
}

/**
 * Costructor to make an empty dataset object, which holds arrays of arrays of inputs
 * and target values.
 */
public Dataset(){
    inputs = new float[0][];
    targets = new float[0][];
    noOfExamples = 0;
    noOfInputValues = 0;
    noOfClasses = 0;
}


public Dataset(ArrayList in, ArrayList tar){
	inputs = new float[in.size()][];
	System.out.print("\nIn size = " + in.size());
	targets = new float[tar.size()][];
	System.out.print("\nTar size = " + tar.size());
	
	for(int i = 0; i < inputs.length; i++){
		inputs[i] = (float[])in.get(i);
		targets[i] = (float[])tar.get(i);
	}
	noOfExamples = inputs.length;
    noOfInputValues = inputs[0].length;
    noOfClasses = targets[0].length;
}

/**
 * Costructor to make a dataset object, which holds arrays of arrays of inputs
 * and target values. The inputs and targets are read in from the specified filename.
 * 
 * Format of the file should be:
 * 
 * >First Line is < #examples, #inputs, #outputs >
 * >Second line onwards are examples, comma seperated. Inputs first. Then one 
 * >entry per output node.
 * 
 * Example file given below for a 2 class problem with three inputs, and 5 examples
 * 
 * --Example.csv----
 * 5,3,2
 * 0,0.1,0.2,0,1
 * 0.8,0.5,0,1,0
 * 0.4,0.2,0.1,1,0
 * 0.3,0.1,0.8,1,0
 * 0.25,0.66,0.1,0,1
 * -----------------
 *
 * @param filename, the location of the file containing the data (String)
 */
public Dataset(String filename){
	BufferedReader myReader = null;
	try{
		// Attempt to open the file
		myReader = new BufferedReader( new FileReader( new File( filename ) ) );
	}
	catch( FileNotFoundException ex ){
		System.err.println( "Datafile '"+filename+"' not found." );
		System.exit(1);
	}
	try{
		//read the first line which contains information about the data
		String line = myReader.readLine();
		//Break that line up into chunks separated by commas
		StringTokenizer myTokenizer = new StringTokenizer( line, "," );
		//first token is number of examples
		noOfExamples = Integer.valueOf(myTokenizer.nextToken()).intValue();
		//second token is number of inputs values    
		noOfInputValues = Integer.valueOf(myTokenizer.nextToken()).intValue();
		//third token is number of classes (targets)
		noOfClasses = Integer.valueOf(myTokenizer.nextToken()).intValue();
		//construct arrays to hold values
		inputs = new float[noOfExamples][];
		targets = new float[noOfExamples][];

		//read in line at a time, tokenize and add to inputs and targets
		for(int i = 0; i < noOfExamples; i++){
	    		line = myReader.readLine();
	    		myTokenizer = new StringTokenizer( line, "," );
	    		inputs[i] = new float[noOfInputValues];
	    		for(int j = 0; j < noOfInputValues; j++){
        			inputs[i][j] = Float.valueOf(myTokenizer.nextToken()).floatValue();
	    		}
	    		targets[i] = new float[noOfClasses];
	    		for(int j = 0; j < noOfClasses; j++){
        			targets[i][j] = Float.valueOf(myTokenizer.nextToken()).floatValue();
	    		}
		}
		myReader.close();
	}
	catch(IOException ex){
		System.out.print("Problem reading from file");
	}
	
}   


/**
 * A method that returns the inputs of the dataset
 * 
 * @return float[][], the inputs
 */
public float[][] getInputSet(){
	return inputs;
}

/**
 * A method that returns the targets of the dataset
 * 
 * @return float[][], the targets
 */
public float[][] getTargetSet(){
	return targets;
}

/**
 * A method that returns the inputs of the dataset for a specified
 * example
 * 
 * @return float[], the inputs
 */
public float[] getInputExample(int index){
	return inputs[index];
}

/**
 * A method that returns the targets of the dataset for a specified
 * example
 * 
 * @return float[], the targets
 */
public float[] getTargetExample(int index){
	return targets[index];
}

/**
 * A method that returns the number of examples in the dataset
 *
 * @return int, the number of examples.
 */
public int getNoOfExamples(){
	return noOfExamples;
}

/**
 * A method that returns the number of inputs in a single example in the dataset
 *
 * @return int, the number of inputs in a single example.
 */
public int getNoOfInputValues(){
	return noOfInputValues;
}


/**
 * A method that returns the number of classes in a single example in the dataset
 *
 * @return int, the number of classes in a single example.
 */
public int getNoOfClasses(){
	return noOfClasses;
}




/**
 * A method that shuffles the dataset to a random order.
 */
public void shuffleData(){    
    //System.out.println("Inputs length = " + inputs.length + ", Targets length = " + targets.length);
    for(int i = 0; i < inputs.length; i++){
	//printIndexedFloatArray(inputs);
        int newLocation = Globals.generalRand.nextInt(inputs.length);
        //System.out.print("\nSwap " +i+" with "+newLocation); 
        float[] tempInput = inputs[newLocation];
        float[] tempTarget = targets[newLocation];
        inputs[newLocation] = inputs[i];
        targets[newLocation] = targets[i];
        inputs[i] = tempInput;
        targets[i] = tempTarget;
        //printIndexedFloatArray(inputs);
    }
}

/**
 * A method that prints a representation of a float array of arrays to the screen
 *
 * @param float[][], the array of arrays of floats to print.
 */
public void printIndexedFloatArray(float[][] a){
    //System.out.println("ARRAY LENGTH = " + a.length);
    for(int i = 0; i < a.length; i++){
        System.out.print("\n["+i+"]\t");
        for(int j = 0; j < a[i].length; j++){
            System.out.print(a[i][j]+"\t");
        }
    }
}

public String toString(){
	String s = "\n";
	for(int i = 0; i < inputs.length; i++){
		for(int j = 0; j < inputs[i].length; j++){
			s = s + Math.round(inputs[i][j]*1000)/1000d + "\t";
		}
		s = s + "\t";
		for(int j = 0; j < targets[i].length; j++){
			s = s + Math.round(targets[i][j]*1000)/1000d + "\t";
		}
		s = s + "\n";
	}
	return s;
}


public void outputToFile(String fileName){
	
	try{
		FileWriter out = new FileWriter(fileName, true);
	    String s = getNoOfExamples() +","+ getNoOfInputValues() +","+ getNoOfClasses() + "\n";
		out.write(s);
	    for(int i = 0; i < inputs.length; i++){
			s = "";
	    	for(int j = 0; j < inputs[i].length; j++){
				s = s + inputs[i][j] + ",";
			}
			for(int j = 0; j < targets[i].length; j++){
				s = s + targets[i][j] + ",";
			}
			s = s + "\n";
			out.write(s);
		}
	    out.close(); 
	}
	catch(IOException e){
		System.out.print("\nIO Exception\n" + e +"\nUnable to write to file");
	}
	
}
    
}
