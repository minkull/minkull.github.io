package components;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class RunModels {

	String databaseName;
	
	//	 the number of nodes in the network
	int inputNodes;
	int hiddenNodes;
	int outputNodes;
	int hiddenLayerNodeType, outputLayerNodeType;
	
	// range of uniform initialisation of mlp weights
	int initRange;
	
	// the learning rade (alpha)
	float learnRate;
	
	//	the penalty strength (gamma, not lambda- see Islam)
	//gamma 0.390625 = lambda 0.75 (for 30 nets).
	//use this equation to convert:
	// lambda = gamma * (2 * ((nets -1)/nets))
	// gamma should be less than nets^2/(2(nets-1)^2)
	float nclPenalty; // used only by the  ensembles
	int nets; // used only by the ensembles
	int trainingSetsNumb; // used only by the incremental ensembles 
	
	// number of max epochs
	int maxEpochs;
	int maxConsecValGrow; // for UP stop criterion
	float glAlpha, minProgress; int stripSize; // for GL stop criterion
	
	public long timeSeed;
	
	public void printParameters()
	{
		System.out.println("Input nodes: " + inputNodes);
		System.out.println("Hidden nodes: " + hiddenNodes);
		System.out.println("Output nodes: " + outputNodes);
		
		if (hiddenLayerNodeType == Node.LOGISTIC)
			System.out.println("Hidden layer node type: Sigmoid logistic");
		else System.out.println("Hidden layer node type: Linear");
		
		if (outputLayerNodeType == Node.LOGISTIC)
			System.out.println("Hidden layer node type: Sigmoid logistic");
		else System.out.println("Hidden layer node type: Linear");
		
		System.out.println("Init range for weights: " + initRange);

		
		System.out.println("\nMax epochs: " + maxEpochs);
		System.out.println("UP max consec val grow: " + maxConsecValGrow);
		System.out.println("GL GL alpha: " + glAlpha);
		System.out.println("GL minProgress: " + minProgress);
		System.out.println("GL strip size: " + stripSize);
		
		System.out.println("\nLearning rate: " + learnRate);
			
	}

	// Read all the parameters. Some of the parameters of the file might not be used 
	// afterwards, depending on the training type
	private void readParameters(String filename)
	{
		BufferedReader myReader = null;
		try{
			// Attempt to open the file
			myReader = new BufferedReader( new FileReader( new File( filename ) ) );
		}
		catch( FileNotFoundException ex ){
			System.err.println( "Datafile '"+filename+"' not found." );
			System.exit(1);
		}
		
		try{
			//read the first line which contains information about the data
			String line = myReader.readLine();
			//Break that line up into chunks separated by commas
			StringTokenizer myTokenizer = new StringTokenizer( line, "=" );
			//first token is the name of the dataset
			String paramName;
	
	
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("seed"))
			{
				timeSeed = Long.valueOf(myTokenizer.nextToken()).longValue();
				line = myReader.readLine();
				myTokenizer = new StringTokenizer( line, "=" );
				paramName = String.valueOf(myTokenizer.nextToken());
			}
			else //	Generate random seed
			{
				Date dt = new Date();
				timeSeed = dt.getTime();
				
			}

			System.out.println("Seed: "+timeSeed);
			Globals.generalRand = new Random(timeSeed);
			
			/*Date dt = new Date();
			long time_seed = dt.getTime();
			//time_seed = 1169811971095L; //1169814536017L; //1169820601214L; //1169811971095L; //1169813742666L; //1169906455778L; //1169902692744L; 
			System.out.println("Seed: "+time_seed);
			Globals.generalRand = new Random(time_seed);*/
			
			if (paramName.contentEquals("database"))
				databaseName = String.valueOf(myTokenizer.nextToken());
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE database=" + databaseName);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("hidden_nodes"))
				hiddenNodes = Integer.valueOf(myTokenizer.nextToken()).intValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE hidden_nodes=" + hiddenNodes);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("init_range"))
				initRange = Integer.valueOf(myTokenizer.nextToken()).intValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE init_range=" + initRange);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("learn_rate"))
				learnRate = Float.valueOf(myTokenizer.nextToken()).floatValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE learn_rate=" + learnRate);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("max_epochs"))
				maxEpochs = Integer.valueOf(myTokenizer.nextToken()).intValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE max_epochs=" + maxEpochs);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("max_consec_val_grow"))
				maxConsecValGrow = Integer.valueOf(myTokenizer.nextToken()).intValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE max_consec_val_grow=" + maxConsecValGrow);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("gl_alpha"))
				glAlpha = Float.valueOf(myTokenizer.nextToken()).floatValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE gl_alpha=" + glAlpha);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("min_progress"))
				minProgress = Float.valueOf(myTokenizer.nextToken()).floatValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE min_progress=" + minProgress);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("strip_size"))
				stripSize = Integer.valueOf(myTokenizer.nextToken()).intValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE strip_size=" + stripSize);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("ncl_penalty"))
				nclPenalty = Float.valueOf(myTokenizer.nextToken()).floatValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE ncl_penalty=" + nclPenalty);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("num_nets"))
				nets = Integer.valueOf(myTokenizer.nextToken()).intValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE num_nets=" + nets);
			line = myReader.readLine();
			myTokenizer = new StringTokenizer( line, "=" );
			
			paramName = String.valueOf(myTokenizer.nextToken()); 
			if (paramName.contentEquals("training_sets_numb"))
				trainingSetsNumb = Integer.valueOf(myTokenizer.nextToken()).intValue();
			else System.err.println("Unrecognized parameter: " + paramName);
			//System.out.println("TESTE training_sets_numb=" + trainingSetsNumb);
			
		}
		catch(IOException ex){
			System.out.print("Problem reading from file");
		}
			
		
	}
	
	public void rMLP(boolean verbose, String parametersFilename) throws UnknownNodeTypeException
	{
		readParameters(parametersFilename);
		
		// The training, testing and validation sets
		Globals.train = new Dataset(databaseName.concat("1.train.csv"));
		Globals.valid = new Dataset(databaseName.concat("1.valid.csv"));
		Globals.test = new Dataset(databaseName.concat("1.test.csv"));
		if(verbose){System.out.println("Data loaded");}
		
		inputNodes = Globals.train.getNoOfInputValues();
		outputNodes = Globals.train.getNoOfClasses();
		hiddenLayerNodeType = Node.LOGISTIC; outputLayerNodeType = Node.LINEAR;
		
		// the number of nodes in the network
		/*inputNodes = Globals.train.getNoOfInputValues();
		hiddenNodes = 10;//5;
		outputNodes = Globals.train.getNoOfClasses();
		hiddenLayerNodeType = Node.LOGISTIC; outputLayerNodeType = Node.LINEAR;
		
		// range of uniform initialisation of mlp weights
		initRange = 2; //2; //1;
		
		// the learning rade (alpha)
		learnRate = 0.05f;
		
		// number of max epochs
		maxEpochs = 50;
		maxConsecValGrow = 5; // for UP stop criterion
		//float glAlpha = 5f, minProgress = 50f; int stripSize = 5; // for GL stop criterion
		glAlpha = 500f; minProgress = 100000f; int stripSize = 5; // for GL stop criterion
		//glAlpha = 5f; minProgress = 15f; int stripSize = 5; // for GL stop criterion
		*/
		
		if (verbose) 
		{
			printParameters();
		}
		
		// establishes the learning parameters
		LearningParameters param = new LearningParameters(learnRate);
		
		MLP mlp = new MLP(inputNodes,hiddenNodes,outputNodes, new MeanSquareErrorFunction());
		mlp.connect(hiddenLayerNodeType, outputLayerNodeType);
		mlp.uniformInitialise(initRange);
		if(verbose){System.out.println("MLP initialised");}

		//mlplearns the training set according to the parameters set.
		//mlp.learnDataset(maxEpochs,param,Globals.train, true);
		//mlp = mlp.learnDatasetUPEarlyStop(Globals.train, Globals.valid, maxConsecValGrow, maxEpochs, param);
		mlp = mlp.learnDatasetGLEarlyStop(Globals.train, Globals.valid, glAlpha, minProgress, stripSize, maxEpochs, param);
		if(verbose){System.out.println("...complete");}
		
		//get results for training and test sets fromt the trained ensemble
		Results trainingResults = mlp.test(Globals.train);
		Results testingResults = mlp.test(Globals.test);
		Results validationResults = mlp.test(Globals.valid);

		// printf the generated MLP: <---fer07/02/07
		System.out.println("\n\n\n\n\n ********* MLP GENERATED ********\n");
		System.out.println(mlp.toSaveString());
		

		// print the testing confusion matrix <---fer07/02/07
		System.out.println("\n\n\n\n\n ********* MLP TESTING RESULTS (confusion matrix and each example classification correctness) ********\n");
		System.out.println(testingResults.toScreenPrintString(1));
		

		//print out results
		System.out.println("\n\n\n\n\nError rate (training):, " + trainingResults.getErrorRate());
		System.out.println("Error rate (validation):, " + validationResults.getErrorRate());
		System.out.println("Error rate (testing):, " + testingResults.getErrorRate());
	}
	
	public void rEnsemble(boolean verbose, int learningType, String parametersFilename) throws UnknownNodeTypeException
	{
		readParameters(parametersFilename);
		// The training and testing sets
		Globals.train = new Dataset(databaseName.concat("1.train.csv"));
		Globals.valid = new Dataset(databaseName.concat("1.valid.csv"));
		Globals.test = new Dataset(databaseName.concat("1.test.csv"));
		if(verbose){System.out.println("Data loaded");}
		
		inputNodes = Globals.train.getNoOfInputValues();
		outputNodes = Globals.train.getNoOfClasses();
		hiddenLayerNodeType = Node.LOGISTIC; outputLayerNodeType = Node.LINEAR;
		
		// the number of nets and nodes in each net
		/*nets = 1;
		inputNodes = Globals.train.getNoOfInputValues();
		hiddenNodes = 5; //5;
		outputNodes = Globals.train.getNoOfClasses();
		hiddenLayerNodeType = Node.LOGISTIC; outputLayerNodeType = Node.LINEAR;
		
		// range of uniform initialisation of mlp weights
		initRange = 1;
		
		// the learning rade (alpha)
		learnRate = 0.05f;
		//the penalty strength (gamma, not lambda- see Islam)
		//gamma 0.390625 = lambda 0.75 (for 30 nets).
		//use this equation to convert:
		// lambda = gamma * (2 * ((nets -1)/nets))
		nclPenalty = 0.390625f;
		
		// number of max epochs
		maxEpochs = 100;
		maxConsecValGrow = 5; // for UP stop criterion
		//glAlpha = 5f; minProgress = 50f; stripSize = 5; // for GL stop criterion
		glAlpha = 500f; minProgress = 100000f; stripSize = 5; // for GL stop criterion
		*/
		
		if (verbose) 
		{
			printParameters();
			System.out.println("NCL Penalty: " + nclPenalty);
			System.out.println("Number of MLPs: " + nets);
			
		}
		
		// combination scheme
		CombinationScheme comb = new MAJ();
		
		//establishes the learning parameters and error function
		LearningParameters param;
		ErrorFunction errorFunction;
		Ensemble ens;
		if (learningType == LearningParameters.NCL)
		{
			param = new LearningParameters(learnRate,nclPenalty,nets);
			errorFunction = new NCLMeanSquareErrorFunction();
			// create ensemble specifying number of nets, the combination scheme and the learning algorithm
			ens = new Ensemble(nets,comb,new NegativeCorrelationLearning());
		}
		else // if (learningType == LearningParameters.STANDARD_BACKPROP)
		{
			param = new LearningParameters(learnRate,nets);
			errorFunction = new MeanSquareErrorFunction();
			// create ensemble specifying number of nets, the combination scheme and the learning algorithm
			ens = new Ensemble(nets,comb,new Backpropagation());
		}
						
		//create the individual networks in the ensemble (all same structure)
		//supply input, hidden nodes (all one layer) and output nodes. 
		//Also specify the type of node in the hidden and output layer (logistic for hidden, linear for output if regression, logistic for classification)
		//finally specify the error function. NCL for a mse function used here
		ens.populate(inputNodes,hiddenNodes,outputNodes,hiddenLayerNodeType,outputLayerNodeType,errorFunction);
		//initialise weights at random from uniform dist. -0.5 to +0.5
		ens.uniformInitialise(initRange);
		if(verbose){System.out.println("Ensemble initialised");}
		

		if(verbose){System.out.println("Training started...");}
		//ensemble learns the training set according to the parameters set.
		//ens.learn(maxEpochs,param,Globals.train);
		//ens = ens.learnUPEarlyStop(Globals.train, Globals.valid, maxConsecValGrow, maxEpochs, param);
		ens = ens.learnGLEarlyStop(Globals.train, Globals.valid, glAlpha, minProgress, stripSize, maxEpochs, param);
		if(verbose){System.out.println("...complete");}
		
		//get results for training and test sets fromt the trained ensemble
		Results trainingResults = ens.test(Globals.train);
		Results testingResults = ens.test(Globals.test);
		Results validationResults = ens.test(Globals.valid);

		// print the errors of each of the MLPs  <---fer07/02/07
		System.out.println("\n\n\n\n\n TESTING RESULTS OF EACH MLP OF THE ENSEMBLE:\n");
		ens.testAndPrintEachMLP(Globals.test, Globals.train, Globals.valid);

		// printf the generated MLP: <---fer07/02/07
		System.out.println("\n\n\n\n\n ********* ENSEMBLE GENERATED ********\n");
		System.out.println(ens.toSaveString());
		

		// print the testing confusion matrix <---fer07/02/07
		System.out.println("\n\n\n\n\n ********* ENSEMBLE TESTING RESULTS (confusion matrix and each example classification correctness) ********\n");
		System.out.println(testingResults.toScreenPrintString(1));

		
		//print out results
		System.out.println("\n\n\n\n\nError rate (training):, " + trainingResults.getErrorRate());
		System.out.println("Error rate (validation):, " + validationResults.getErrorRate());
		System.out.println("Error rate (testing):, " + testingResults.getErrorRate());

		
	}

	// FAZER<---
	// The names of the datasets have to be
	// name0.csv for the test dataset
	// nameX_train.csv for the Xth train dataset
	// nameX_valid.csv for the Xth valid dataset
	public void rIncEnsemble(boolean verbose, int learningType, int incrementalType, String parametersFilename) throws UnknownNodeTypeException
	{
		readParameters(parametersFilename);
		
		// The training and testing sets
		Globals.train = new Dataset(databaseName.concat("1_train.csv"));
		Globals.valid = new Dataset(databaseName.concat("1_valid.csv"));
		Globals.test = new Dataset(databaseName.concat("0.csv"));
		if(verbose){System.out.println("Datasets loaded.");}
		
		inputNodes = Globals.train.getNoOfInputValues();
		outputNodes = Globals.train.getNoOfClasses();
		hiddenLayerNodeType = Node.LOGISTIC; outputLayerNodeType = Node.LINEAR;
		
		/*int trainingSetsNumb = 9;
		
		// the number of nets and nodes in each net
		nets = 1; // number of nets of the ens, or initial number of nets (=1) to the growing incremental ens.
		inputNodes = Globals.train.getNoOfInputValues();
		hiddenNodes = 5; //5;
		outputNodes = Globals.train.getNoOfClasses();
		hiddenLayerNodeType = Node.LOGISTIC; outputLayerNodeType = Node.LINEAR;
		
//		 range of uniform initialisation of mlp weights
		initRange = 2;
		
		// the learning rade (alpha)
		learnRate = 0.1f;
		//the penalty strength (gamma, not lambda- see Islam)
		//gamma 0.390625 = lambda 0.75 (for 30 nets).
		//use this equation to convert:
		// lambda = gamma * (2 * ((nets -1)/nets))
		// gamma should be less than nets^2/(2(nets-1)^2)
		nclPenalty = 0.390625f;
		
		// number of max epochs
		maxEpochs = 100;
		maxConsecValGrow = 5; // for UP stop criterion
		//float glAlpha = 5f, minProgress = 50f; int stripSize = 5; // for GL stop criterion
		//glAlpha = 500f; minProgress = 100000f; stripSize = 5; // for GL stop criterion
		glAlpha = 5f; minProgress = 20f; stripSize = 5; // for GL stop criterion
		*/
		

		
		// combination scheme
		CombinationScheme comb = new MAJ();
		
		//establishes the learning parameters and error function
		LearningParameters param;
		ErrorFunction errorFunction;
		Ensemble ens;
		if (learningType == LearningParameters.NCL)
		{
			param = new LearningParameters(learnRate,nclPenalty,nets);
			errorFunction = new NCLMeanSquareErrorFunction();
			// create ensemble specifying number of nets, the combination scheme and the learning algorithm
			if (incrementalType == LearningParameters.GROWING_INCREMENTAL)
				ens = new Ensemble(nets,comb,new IncNegativeCorrelationLearning());
			else ens = new Ensemble(nets,comb,new NegativeCorrelationLearning());
		}
		else // if (learningType == LearningParameters.STANDARD_BACKPROP)
		{
			param = new LearningParameters(learnRate,nets);
			errorFunction = new MeanSquareErrorFunction();
			// create ensemble specifying number of nets, the combination scheme and the learning algorithm
			if (incrementalType == LearningParameters.GROWING_INCREMENTAL)
			{
				nclPenalty = 0f;
				ens = new Ensemble(nets,comb,new IncNegativeCorrelationLearning());
			}
			else ens = new Ensemble(nets,comb,new Backpropagation());
		}
						
		if (verbose) 
		{
			printParameters();
			System.out.println("NCL Penalty: " + nclPenalty);
			System.out.println("Number of MLPs: " + nets);
			
		}
		
		//create the individual networks in the ensemble (all same structure)
		//supply input, hidden nodes (all one layer) and output nodes. 
		//Also specify the type of node in the hidden and output layer (logistic for hidden, linear for output if regression, logistic for classification)
		//finally specify the error function. NCL for a mse function used here
		ens.populate(inputNodes,hiddenNodes,outputNodes,hiddenLayerNodeType,outputLayerNodeType,errorFunction);
		//initialise weights at random from uniform dist. -0.5 to +0.5
		ens.uniformInitialise(initRange);
		if(verbose){System.out.println("Ensemble initialised");}
		

		if(verbose){System.out.println("Training started...");}
		
		int lastAddedMLPPosition;
		Results testingResults, validationResults, trainingResults;
		Dataset []oldTrainDatasets = new Dataset[trainingSetsNumb];
		for (int i=1; i<= trainingSetsNumb; i++)
		{
			if(verbose){System.out.println("Training/validation set " + i);}
			
			if (i != 1)
			{
				// change train and valid sets
				Globals.train = new Dataset(databaseName.concat(i + "_train.csv"));
				Globals.valid = new Dataset(databaseName.concat(i + "_valid.csv"));
				if(verbose){System.out.println("Datasets loaded.");}
				
				if (incrementalType == LearningParameters.GROWING_INCREMENTAL)
				{
					lastAddedMLPPosition = ens.addMLP(inputNodes,hiddenNodes,outputNodes,hiddenLayerNodeType,outputLayerNodeType,errorFunction);
					ens.getNetwork(lastAddedMLPPosition).uniformInitialise(initRange);
					
					if(verbose){System.out.println("New MLP added to the ensemble.");}
				}
				
			}
			
			//ensemble learns the training set according to the parameters set.
			//ens.learn(maxEpochs,param,Globals.train);
			//ens = ens.learnUPEarlyStop(Globals.train, Globals.valid, maxConsecValGrow, maxEpochs, param);
			ens = ens.learnGLEarlyStop(Globals.train, Globals.valid, glAlpha, minProgress, stripSize, maxEpochs, param);
			
			trainingResults = ens.test(Globals.train);
			validationResults = ens.test(Globals.valid);
			testingResults = ens.test(Globals.test);
			

			//	print out results
			System.out.println("\n\n\n\n\nError rate (training):, " + trainingResults.getErrorRate());
			System.out.println("Error rate (validation):, " + validationResults.getErrorRate());
			System.out.println("Error rate (testing):, " + testingResults.getErrorRate());
				
			if(i>1)
			{
				int tmp;
				for (int old = 0; old < i-1; old++)
				{
					tmp = old+1;
					System.out.println("Old train error " + tmp + ":, " + ens.test(oldTrainDatasets[old]).getErrorRate());
				}
			}

			// print the errors of each of the MLPs  <---fer07/02/07
			System.out.println("\n\n\n\n\n TESTING RESULTS OF EACH MLP OF THE ENSEMBLE:\n");
			ens.testAndPrintEachMLP(Globals.test, Globals.train, Globals.valid);
			

			// printf the generated MLP: <---fer07/02/07
			System.out.println("\n\n\n\n\n ********* ENSEMBLE GENERATED ********\n");
			System.out.println(ens.toSaveString());
		

			// print the testing confusion matrix <---fer07/02/07
			System.out.println("\n\n\n\n\n ********* ENSEMBLE TESTING RESULTS (confusion matrix and each example classification correctness) ********\n");
			System.out.println(testingResults.toScreenPrintString(1)); 
			
			System.out.println("-------------------------------------------------------\n");
			
			// Update old train datasets
			oldTrainDatasets[i-1] = new Dataset(Globals.train.inputs.clone(), Globals.train.targets.clone());
		}

		if(verbose){System.out.println("...complete");}
		//get results for training and test sets fromt the trained ensemble

		
		

		
	}


}
