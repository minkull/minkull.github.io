package components;

public class WTA extends CombinationScheme{
	
	public WTA(){
		type = "WINNER_TAKES_ALL";
	}
	
	public float[] combineOutputs(float[][] ensembleOutputs){
		float[] combinedOutput = new float[ensembleOutputs[0].length];
		
		// Notice that in this case, the outputs of the ensemble will not be only either 0
		// or 1. They will be inside the [0,1] interval. In the majority voting this is 
		// different.
		int[] highestOutput = ArrayHandler.maxCellLocation(ensembleOutputs);
		combinedOutput = ensembleOutputs[highestOutput[0]];
		
		return combinedOutput;
	}

}
