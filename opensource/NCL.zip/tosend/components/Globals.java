/*
 * globals.java
 *
 * Created on 28 April 2005, 17:57
 */

package components;
import java.util.*;
import java.io.*;

/**
 *
 * @author  duell
 */
public class Globals {
   
    public static Random generalRand;
    public static String algorithm;
    public static String dataName;
    public static int run;
    
    public static BufferedWriter out;
    
    public static Dataset train,valid,test;
    
    public void setGeneralRand(Random r){
        generalRand = r;
    }
    
    public static void outputString(String s){
    	try{
    		out.write(s);
		}catch(IOException e){
			System.out.println("IOException");
		}
    }
}