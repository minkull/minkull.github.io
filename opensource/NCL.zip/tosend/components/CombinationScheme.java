package components;

public abstract class CombinationScheme {
	String type;
	public abstract float[] combineOutputs(float[][] ensembleOutputs);
	
	public String toString(){
		return type;
	}
	
	public static CombinationScheme createCombinationScheme(String s){
		if(s.equals("SIMPLE_AVERAGE")){
			return new AVG();
		}
		if(s.equals("MAJORITY_VOTE")){
			return new MAJ();
		}
		if(s.equals("WINNER_TAKES_ALL")){
			return new WTA();
		}
		return null;
	}
}
